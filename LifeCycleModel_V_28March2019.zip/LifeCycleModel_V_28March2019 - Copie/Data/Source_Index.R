# Etienne Rivot
# 05 march 2019

# Names of SU and country by order as considered in the model(from 1:24)
# Country (size = 17) are SU summed by country
# Colors and Type Points are used for plots
 
regions24 <- c(	"LB", "NF", "QB", "GF", "SF", "US", 
			"FR", "E&W", "IR", "N.IR", "SC.W", "SC.E", "IC.SW", 
			"IC.NE", "SW", "NO.SE", "NO.SW", "NO.MI", "NO.NO", "FI", "RU.KB", "RU.KW", "RU.AK", "RU.RP")

country17 <- c(	"LB", "NF", "QB", "GF", "SF", "US",
			"FR", "E&W", "IR", "N.IR", "SC", "IC.SW",
			"IC.NE","SW","NO","FI","RU")

country17Full <- c(	"Labrador", "Newfoundland", "Quebec", "Gulf", "Scotia-Fundy", "US", 
				"France", "England&Wales", "Ireland", "Ireland.N", "Scotland", "Iceland.SW",
				"Iceland.NE","Sweden","Norway","Finland","Russia")

colors24 <- c(	"#1bc253", "#d3fe6c", "#aebd68", "#a4eb94", "#0a681b", "#0ef906", 
				"#ea9cea", "#f90509", "#f06107", "#7b040c", "#fed791", "#e7d20f", "#bd5254",
				"#0af5fd", "#041f55", "#1d86fe", "#bcfffe", "#a6cee3", "#aebaca", "#1d00F8", "#47046c", "#5c38ff", "#c4b7f6", "#7c00d5")

colors17 <- c(	"#1bc253", "#d3fe6c", "#aebd68", "#a4eb94", "#0a681b", "#0ef906",
				"#ea9cea", "#f90509", "#f06107", "#fed791", "#e7d20f", "#bd5254",
				"#0af5fd","#47046c",  "#a6cee3", "#1d00F8", "#c4b7f6")
			
typepoint24 <- c(	1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 2, 1, 1, 1, 2)