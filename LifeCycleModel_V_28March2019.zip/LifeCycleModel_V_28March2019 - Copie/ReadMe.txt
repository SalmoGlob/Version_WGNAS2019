ReadMe

----------------
Etienne Rivot & Maxime Olmos
V march 2019
----------------

Here are a suite of programs to run the Life Cycle Model.
Read also the documentation in the Documenttion Directory.

* 1_Run_Life_Cycle_Nimble.R
Master R script to run the Life Cycle Model - Hindcasting phase = bayesian fit to the historical series of data
Reads three key files in other directories
- Model Directory - "model_nimble.txt" = contains the nimble code
- Data Directory - "Const_nimble.RData" and "Data_nimble.RData" = contains the data needed for the Life cycle model (formated to be read by nimble)
- Inits Directory  - "inits_nimble.RData" = contains the inits needed for the Life Cycle Model

Generates mcmc outputs, stored in the Results directory with the name "mcmc_nimble.RData"

* 2_Plot_results_fit.R
R script
Creates some figures to explore the results
Reads files in other directories
- Data Directory - "Const_nimble.RData" and "Data_nimble.RData" = contains the data needed for the Life cycle model (formated to be read by nimble)
- Results Directory  - "mcmc_nimble.RData" = the mcmc samples used to make graphics

IMPORTANT NOTE : mcmc output files are typically big files (lots of mcmc samples for a lot of variables). 
For this reason, the Results Directory in this present deposit does not contain any files.
1_Run_Life_Cycle_Nimble.R has to be run BEFORE being able to run "2_Plot_results_fit.R" and "3_run_Forecasting.R"

* 3_run_Forecasting.R
R script
Forecast the population dynamics using a clone of the Life Cycle Model written in R, and integrating parameters uncertainty by drawing parameters values in the mcmc samples
Different catshes scenarios at West Greenland and Faroes fisheries are defined at the beginning of the program.
Reads files in other directories
- Data Directory
. "Const_nimble.RData" and "Data_nimble.RData" = contains the data needed for the Life cycle model (formated to be read by nimble)
. "Data_CL.txt" = contains the conservation limits for each stock unit
. "Data_FA_Fishery_TedPotterWGNAS2015.txt" and "Data_WG_fishery_GeraldChaputWGNAS2018.csv" = contains key data to run catch scenarios at West Greenland and Faroes fisheries.
- Results Directory  - "mcmc_nimble.RData" = the mcmc samples used to make graphics

