# Construction on appropriate inits
# SIMULATION from the nimble model with some nodes fixed to specified values
# This program reads the model coded in Nimble language (=BUGS language)
# in "nimble_model.txt" file

# V. - E. Rivot, M. Olmos - 28 March 2019

rm(list=ls(all=TRUE))

library(nimble)
library(coda)
library(RColorBrewer)


# Load and format data for Nimble
# ------------------------------------------------
load("Data_nimble.RData")
load("Const_nimble.RData")



# Load values of model nodes that must be fixed
# for simulation
# ------------------------------------------------

load("Fixed_for_simul.RData")
Fix <- Fixed_for_simul
names(Fix)



# Load the model and create and object named mymod to be used for simulation
# ------------------------------------------------

source("model_nimble.r")

mymod <- nimbleModel(code = model.nimble, name = 'model.nimble', 
                     constants = Const_nimble, data = Data_nimble)



# Assign fixed values (carefully chosen) to model nodes that shouldn't be simulated
# ------------------------------------------------

mymod$N1.pr          <- Fix$N1.pr
mymod$N2             <- Fix$N2
mymod$h.hw.1SW       <- Fix$h.hw.1SW
mymod$h.hw.2SW       <- Fix$h.hw.2SW
mymod$h5.NAC.1       <- Fix$h5.NAC.1
mymod$h5.NEAC.1      <- Fix$h5.NEAC.1
mymod$h5.NAC.2.lab   <- Fix$h5.NAC.2.lab
mymod$h5.NAC.2.other <- Fix$h5.NAC.2.other
mymod$h5.NAC.3.other <- Fix$h5.NAC.3.other
mymod$h8.NAC.1       <- Fix$h8.NAC.1
mymod$h8.NEAC.1      <- Fix$h8.NEAC.1
mymod$h8.2           <- Fix$h8.2
mymod$h8.NAC.3       <- Fix$h8.NAC.3
mymod$h8.NEAC.3      <- Fix$h8.NEAC.3
mymod$h8.NAC.4.other <- Fix$h8.NAC.4.other
mymod$h8.NAC.4.lab   <- Fix$h8.NAC.4.lab
mymod$h8.NAC.5.other <- Fix$h8.NAC.5.other

mymod$logit.theta3   <- Fix$logit.theta3
mymod$logit.theta4   <- Fix$logit.theta4

# mymod$M              <- Fix$M


# Simulate all nodes of the model except those that have been fixed 
# ------------------------------------------------

# Step 1 - Identify the indices of nodes that must be simulated
#          (versus nodes that are fixed)	 
# -------------------------------------------


# All Nodes of the model

All_Nodes <- mymod$getNodeNames(returnScalarComponents = TRUE)
All_Nodes_names <- mymod$getVarNames(includeLogProb = FALSE, nodes=All_Nodes)




# Find the index of nodes that are fixed

# Index <- NULL
# for (i in 1:length(Fix))
# {
#   var <- names(Fix[i])
#   I <- which(substr(All_Nodes,1,nchar(var)+1)==paste(var,"[",sep=""))
#   Index <- c(Index,I)
# }

Index <- NULL
for (i in 1:length(Fix))
{
  var <- names(Fix[i])
  I <- which(All_Nodes_names == var)
  Index <- c(Index,I)
}


# Keep only the node that MUST be simulated
#(Remove the node that are fixed)

# Nodes_to_simulate <- All_Nodes[-Index]
Nodes_to_simulate <- All_Nodes_names[-Index]



# Step 2 - Simulate all nodes except those fixed (used as constraint)
# ---------------------------------------------------------

# Simulation for inits 1
# ----------------------
# Simulation only of nodes that have to be simulated
# other nodes are fixed
set.seed(seed=1) 
mymod$simulate(nodes = Nodes_to_simulate)


# Check that fixed values have not changed 
# To be sure that fixed nodes were not simulated
mymod$logit.theta3 - Fix$logit.theta3
mymod$N1.pr - Fix$N1.pr

mymod1 <- mymod


# Simulation for inits 2
# ----------------------
set.seed(seed=2)
mymod$simulate(nodes = Nodes_to_simulate)
mymod2 <- mymod


# Create inits and save 
# -------------------------------------------------------------------------

# Get all stochastic nodes only (only stochastic nodes must really be given a inits)
# Stochastic nodes that are "data" are also excluded as no inits is required
# inits_nodes <- mymod$getNodeNames(stochOnly = TRUE, includeData = FALSE, returnType="names")
# names_inits_nodes <- mymod$getVarNames(includeLogProb = FALSE, nodes=inits_nodes)

inits_nodes <- mymod$getNodeNames(stochOnly = FALSE, includeData = FALSE, returnType="names")
names_inits_nodes <- mymod$getVarNames(includeLogProb = FALSE, nodes=inits_nodes)


inits1 <- list()

for (i in 1:length(names_inits_nodes))
{
  inits1[[i]] <- mymod1[[names_inits_nodes[i]]]
}

inits2 <- list()

for (i in 1:length(names_inits_nodes))
{
  inits2[[i]] <- mymod2[[names_inits_nodes[i]]]
}


names(inits1) <- names_inits_nodes
names(inits2) <- names_inits_nodes

inits <- list(inits1,inits2)

save(inits,file="inits_nimble.RData")




# CHECK that simulated abundance match with data
# --------------------------------------------------------------------

# Data to be compared to simulations
 
N6     <-  exp(Data_nimble$log.R1SW.m + 0.5/Const_nimble$log.R1SW.tau)
N9     <-  exp(Data_nimble$log.R2SW.m + 0.5/Const_nimble$log.R2SW.tau)
Chw.1SW   <- exp(Data_nimble$log.hwC1SW.m)
Chw.2SW   <- exp(Data_nimble$log.hwC2SW.m)

check_data24 <- c("N6","N9","Chw.1SW","Chw.2SW")

year1 <- 1971
n.years <- 44
years <- year1:(year1 + n.years-1)

size.text <- 1
size.labels <- 0.8
cex.abc <- 1
box.size <- 0.5
col1 <- rep("white",50)
y.label = ""
x.label = " "

N <- 24
Regions <- c("LB","NF","QB","GF","SF","US",
             "FR","EW","IR","NI_FB","SC_WE", "SC_EA","IC_SW",
             "IC_NE","SW","NO_SE","NO_SW", "NO_MI", "NO_NO", "FI","RU_KB", "RU_KW","RU_AK", "RU_RP")

color=brewer.pal(n = 9, name = "Paired")


for (i in 1:length(check_data24))
{

  X   <- paste(check_data24[i])
  var <- get(X)

windows()
par(mfrow=c(3,4))
  
for (r in 1:N)
 {
    plot(var[,r],pch=20,ylim=c(min(var[,r]),max(var[,r])),cex.main=1.2,
         ylab=x.label, xlab="", cex.lab=1, cex.axis=1, type="l", lwd=2,
         xaxt="n", yaxt="n", lty=1, col="black", main=paste(X," ",Regions[r],sep=""),axes=F)
    lines(mymod1[[X]][,r],lwd=2,lty=2,col=color[1])
    lines(mymod2[[X]][,r],lwd=2,lty=2,col=color[2])
    axis(side =1,at=c(seq(1,(n.years),4)), labels = years[c(seq(1,(n.years),4))], cex.axis=size.labels,las=1)
    axis(side =2, cex.axis=size.labels,las=2)
    legend("topright",legend=c("Data","Simulation"), bty="n",lty=c(1,2),lwd=2,col=c("black",color[1]))
    
  }
}



