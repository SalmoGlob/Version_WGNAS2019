# Use data and Simplified back-calculation from model equation to find appropriate 
# fixed values to constrain Nimble simulation to create appropriate inits 
# for the life cycle

# V. - E. Rivot, M. Olmos - 28 March 2019

rm(list=ls(all=TRUE))

library(nimble)
library(coda)
library(RColorBrewer)



# Load and format data for Nimble

load("Data_nimble.RData")
load("Const_nimble.RData")


# Load Parameters

# For loop
N     <- Const_nimble$N
n     <- Const_nimble$n
nSm   <- Const_nimble$nSm
N.NAC <- Const_nimble$N.NAC
N.NEAC <- Const_nimble$N.NEAC

# Abundances

N1       <- matrix(NA,n,N)
log.N2.m <- matrix(NA,n,N)
N2 		<- matrix(NA,(n-1),N)
theta1.ddp <- matrix(NA,n,N)
N3     <- array(NA,c(50,nSm,N))
N3.tot <- matrix(NA,(n-1),N)
N5     <- matrix(NA,(n-1),N)
N5.1.1 <- matrix(NA,(n-1),N.NAC)
N5.1.2 <- matrix(NA,(n-1),N.NAC)
N5.1   <- matrix(NA,(n-1),N)
N6     <- matrix(NA,(n-1),N)
N7     <- matrix(NA,n,N)
N8     <- matrix(NA,(n-1),N)
N8.1   <- matrix(NA,(n-1),N)
N8.2   <- matrix(NA,(n-1),N)
N8.3.1 <- matrix(NA,n,N.NAC)
N8.3.2 <- matrix(NA,n,N.NAC)
N8.3   <- matrix(NA,n,N)
N9     <- matrix(NA,n,N)
N10    <- matrix(NA,n,N)

# Harvest rates

h.hw.1SW       <- matrix(NA,n-1,N)
h.hw.2SW       <- matrix(NA,n,N)
h5.NAC.1       <- NULL
h5.NEAC.1      <- matrix(NA,(n-1),N.NEAC)
h5.NAC.2.other <- NULL
h5.NAC.2.lab   <- NULL
h5.NAC.3.other <- NULL
h8.NAC.1       <- NULL
h8.NEAC.1      <- matrix(NA,(n-1),N.NEAC)
h8.2          <- matrix(NA,(n-1),N)
h8.NAC.3       <- NULL
h8.NEAC.3      <- matrix(NA,n,N.NEAC)
h8.NAC.4.other <- NULL
h8.NAC.4.lab   <- NULL
h8.NAC.5       <- NULL

# Captures

C5.NEAC.1 <- matrix(NA,(n-1),N.NEAC)
C8.NEAC.1 <- matrix(NA,(n-1),N.NEAC)
C8.2     <- matrix(NA,n,N)
C8.NEAC.3 <- matrix(NA,n,N.NEAC)

C5.NEAC.1.tot  <- exp(Data_nimble$log.CF1.m.m         + 0.5/Const_nimble$log.CF1.m.tau)
C5.NAC.1.tot   <- exp(Data_nimble$log.C1.Nf.3_7.m     + 0.5/Const_nimble$log.C1.Nf.3_7.tau)
C5.NAC.2.lab   <- exp(Data_nimble$log.C1.tot.Lb.m     + 0.5/Const_nimble$log.C1.tot.Lb.tau)
C5.NAC.2.other <- exp(Data_nimble$log.C1.LbNf.other.m + 0.5/Const_nimble$log.C1.LbNf.other.tau)
C5.NAC.3.tot   <- exp(Data_nimble$log.C1.SPM.m        + 0.5/Const_nimble$log.C1.SPM.tau)
C8.NEAC.1.tot  <- exp(Data_nimble$log.CF1.nm.m        + 0.5/Const_nimble$log.CF1.nm.tau)
C8.NAC.1.tot   <- exp(Data_nimble$log.C1.nm.LbNf.m    + 0.5/Const_nimble$log.C1.nm.LbNf.tau)
C8.2.tot      <- exp(Data_nimble$log.CG2.m           + 0.5/Const_nimble$log.CG2.tau)
C8.NEAC.3.tot  <- exp(Data_nimble$log.CF2.m           + 0.5/Const_nimble$log.CF2.tau)
C8.NAC.3.tot   <- exp(Data_nimble$log.C2.Nf.3_7.m     + 0.5/Const_nimble$log.C2.Nf.3_7.tau)
C8.NAC.4.lab   <- exp(Data_nimble$log.C2.tot.Lb.m     + 0.5/Const_nimble$log.C2.tot.Lb.tau)
C8.NAC.4.other <- exp(Data_nimble$log.C2.LbNf.other.m + 0.5/Const_nimble$log.C2.LbNf.other.tau)
C8.NAC.5.tot   <- exp(Data_nimble$log.C2.SPM.m        + 0.5/Const_nimble$log.C2.SPM.tau)

sigma2.s <- log(Const_nimble$CV.dummy*Const_nimble$CV.dummy + 1)
tau.dummy <- 1/sigma2.s 

Chw.1SW   <- exp(Data_nimble$log.hwC1SW.m        + 0.5/tau.dummy)
Chw.2SW   <- exp(Data_nimble$log.hwC2SW.m        + 0.5/tau.dummy)

# Initialisation

N1.pr <- matrix(NA,(nSm +1),N)
N2.pr <- matrix(NA,(nSm +1),N)
N3.pr <- array(NA,c(14,nSm,N))

log.N1.pr     <- matrix(NA,(nSm +1),N)
theta1.ddp.pr <- matrix(NA,(nSm +1),N)
mu.psm.pr     <- matrix(NA,nSm,N)
prop_gamma.pr <- array(NA,c((nSm +1),nSm,N))
psm.stoch.pr  <- array(NA,c((nSm +1),nSm,N))

# Other

mu.psm     <- matrix(NA,nSm,N)
prop_gamma <- array(NA,c(n,nSm,N))
psm.stoch  <- array(NA,c(n,nSm,N))

# Mortality

M <- Const_nimble$E.M

# Survival

theta8.2.3.NAC    <- exp(-M * Const_nimble$deltat.8.2.3.NAC)
theta8.2.2.NEAC   <- exp(-M * Const_nimble$deltat.8.2.2.NEAC)
theta8.2.2.NAC  <- exp(-M * Const_nimble$deltat.8.2.2.NAC)
theta8.2.1.NAC  <- exp(-M * Const_nimble$deltat.8.2.1.NAC)
theta8.2.1.NEAC <- exp(-M * Const_nimble$deltat.8.2.1.NEAC)
theta8.NAC.2  <- exp(-M * Const_nimble$deltat.8.2.NAC)
theta8.NEAC.2 <- exp(-M * Const_nimble$deltat.8.2.NEAC)
theta8.1.NAC  <- exp(-M * Const_nimble$deltat.8.1.NAC)
theta8.1.NEAC <- exp(-M * Const_nimble$deltat.8.1.NEAC)
theta5.3.NAC    <- exp(-M * Const_nimble$deltat.5.3.NAC)
theta5.2.NEAC   <- exp(-M * Const_nimble$deltat.5.2.NEAC)
theta5.2.NAC  <- exp(-M * Const_nimble$deltat.5.2.NAC)
theta5.1.NAC  <- exp(-M * Const_nimble$deltat.5.1.NAC)
theta5.1.NEAC <- exp(-M * Const_nimble$deltat.5.1.NEAC)

theta4 <- matrix(NA,n,N)
theta3 <- matrix(NA,n,N)


############################################################
# From N9 to N3 (forward)
############################################################
N6     <-  exp(Data_nimble$log.R1SW.m + 0.5/Const_nimble$log.R1SW.tau)
N9     <-  exp(Data_nimble$log.R2SW.m + 0.5/Const_nimble$log.R2SW.tau)

# N7 & N10
# ----------------------------------------------
h.hw.1SW  <- Chw.1SW[1:(n-1),] / N6[1:(n-1),]
h.hw.2SW  <- Chw.2SW / N9


for (r in 1:N)
{
  
  N7[1,r] <- N6[1,r] * (1- h.hw.1SW[1,r])
  N10[1,r] <- N9[1,r] * (1-h.hw.2SW[1,r])   + Const_nimble$Stocking.2SW[1,r]
  
  for (t in 2:(n-1))
	{
	N7[t,r]  <- max(((N6[t,r] * (1- h.hw.1SW[t,r]))* (1 - Const_nimble$prop.delSp.1SW[t,r])) + ((N6[t-1,r] * (1- h.hw.1SW[t-1,r]))* Const_nimble$prop.delSp.1SW[t-1,r]) - exp(Data_nimble$log.Chw.1SW.delSp.m[t,r]),1)
	}
  for (t in 2:n)
	{
	N10[t,r] <- max(((N9[t,r] * (1- h.hw.2SW[t,r]))* (1 - Const_nimble$prop.delSp.2SW[t,r])) + ((N9[t-1,r] * (1- h.hw.2SW[t-1,r]))* Const_nimble$prop.delSp.2SW[t-1,r]) - exp(Data_nimble$log.Chw.2SW.delSp.m[t,r]) + Const_nimble$Stocking.2SW[t,r],1)
	}
}

# N1
# ----------------------------------------------

for (r in 1:N)
{  
  for (t in 1:(n-1))
  {
    N1[t,r] <- N7[t,r]*Const_nimble$eggs[1,r] + N10[t,r]*Const_nimble$eggs[2,r]
  }
}

# N2
# ----------------------------------------------


    for (r in 1:N)
    {  
      for (t in 1:(n-1))
      {
		# theta1.ddp[t,r] <-  Const_nimble$a/(1+Const_nimble$B[r]*N1[t,r])
		theta1.ddp[t,r] <-  Const_nimble$a
	}}
		
for (r in 1:N)
    {  
      for (t in 1:(n-1))
      {
		log.N2.m [t,r] <- log(theta1.ddp[t,r]*N1[t,r] + Const_nimble$eps)
		N2[t,r] <- exp(log.N2.m[t,r])
      }
    }

# N3
# ----------------------------------------------

for (r in 1:N) 
{
  # Proportion
  for (k in 1:nSm)
  {
    mu.psm[k,r] <- (Const_nimble$p.smolt[k,r])*Const_nimble$N.Sample.sm +1
    
    for (t in 1:n)
    {
      prop_gamma[t,k,r] <- rgamma(1,mu.psm[k,r],1)
    }
  }
  
  for (k in 1:nSm)
  {
    for (t in 1:n)
    {
      psm.stoch[t,k,r] <- prop_gamma[t,k,r]/sum(prop_gamma[t,1:nSm,r])
    }
  }


  # N3
  for (t in 1:(n-1))
  {
    for (k in 1:nSm)
    {
      N3[t+1+k,k,r] <- psm.stoch[t,k,r]*N2[t,r]
    }
  }
}  


# ----------------------------------------------
# INITIALISATION OF THE LOOP ON t
# ---------------------------------------------- 

# N1 1964-1970
# ----------------------------------------------
CV.N1.pr <- 0.2
sigma2.N1.pr <- log(CV.N1.pr * CV.N1.pr + 1)
sigma.N1.pr <- sqrt(sigma2.N1.pr)

for (r in 1:N)
{  
  for(t in 1:(nSm+1))
  {
    log.N1.pr[t,r] <- rnorm(1,Const_nimble$mu.N1.pr[r],sigma.N1.pr)
    N1.pr[t,r] <- exp(log.N1.pr[t,r])
  }
}	


# N2 1964-1970
# ----------------------------------------------

for (r in 1:N)
{
	for(t in 1:(nSm+1))
	{
	# theta1.ddp.pr[t,r] <- Const_nimble$a/(1+Const_nimble$B[r]*N1.pr[t,r])
	theta1.ddp.pr[t,r] <- Const_nimble$a
	N2.pr[t,r] <- N1.pr[t,r]*theta1.ddp.pr[t,r] 
	}  
}


# N3
# ----------------------------------------------

for (r in 1:N) 
{
  
  for (k in 1:nSm)
  {
    mu.psm.pr[k,r] <- (Const_nimble$p.smolt[k,r])*Const_nimble$N.Sample.sm +1
    
    for (t in 1:(nSm+1))
    {
      prop_gamma.pr[t,k,r] <- rgamma(1,mu.psm.pr[k,r],1)
    }
  }
  
  # Reparition of smolt for years 64 to 70
  for (k in 1:nSm)
  {
    for (t in 1:(nSm+1))
    {
      psm.stoch.pr[t,k,r] <- prop_gamma.pr[t,k,r]/sum(prop_gamma.pr[t,1:nSm,r])
      N3.pr[t+k+1,k,r] <- psm.stoch.pr[t,k,r] * N2.pr[t,r]
    }
  }

  # The year 71 correspond to the 8th line in N3.pr (from 64 to 70)
  # The first year that have to be completed
  
  for(k in 1:nSm)
  {
    N3[1,k,r] <- N3.pr[8,k,r]
  }
  
  # step filling of years 72:77 from N3.pr of years 64 to 70
  for (k in 1:nSm)
  {
    for (kk in k:nSm)
    {
      N3[k+1,kk,r] <- N3.pr[k+8,kk,r]
    }
  }
  
  # N3.tot of all years 
  for (t in 1:(n-1))
  { 
    N3.tot[t,r] <- sum(N3[t,1:nSm,r])
  }
}

############################################################
# From N9 to N4 (backward)
############################################################


# N8.3
# ----------------------------------------------

for (t in 1:n)
{
  #NAC
  for (r in 1:N.NAC) {
    N8.3[t,r] <- N9[t,r] / theta8.2.3.NAC
  }
  #NEAC
  for (r in 7:N) {
    N8.3[t,r] <- N9[t,r] / theta8.2.2.NEAC
  }
}

# N8.3.2
# ----------------------------------------------

for (t in 1:n)
{  
  N8.3.2[t,1]   <- N8.3[t,1]/theta8.2.2.NAC
  h8.NAC.5[t]   <- C8.NAC.5.tot[t]/(sum(N8.3[t,2:6])+C8.NAC.5.tot[t])
  
  for (r in 2:6) {
    N8.3.2[t,r] <- N8.3[t,r] / ((1-h8.NAC.5[t])*theta8.2.2.NAC)
  }
}  


# N8.3.1
# ----------------------------------------------

for (t in 1:n)
{  
  N8.3.1[t,1]       <- N8.3.2[t,1] + C8.NAC.4.lab[t]
  h8.NAC.4.lab[t]   <- C8.NAC.4.lab[t]/(N8.3.2[t,1]+C8.NAC.4.lab[t])
  h8.NAC.4.other[t] <- C8.NAC.4.other[t]/(sum(N8.3.2[t,2:6])+C8.NAC.4.other[t])
  
  for (r in 2:6) {
    N8.3.1[t,r] <- N8.3.2[t,r] / (1-h8.NAC.4.other[t])
  }
}

# N8.2
# ----------------------------------------------

#NAC
for (t in 1:n) {  
  h8.NAC.3[t] <-  C8.NAC.3.tot[t]/(sum(N8.3.1[t,1:N.NAC])+C8.NAC.3.tot[t])
}

for (t in 1:(n-1)) { 
  for (r in 1:N.NAC) {
    N8.2[t,r] <- N8.3.1[t+1,r] / ((1-h8.NAC.3[t+1])*theta8.2.1.NAC)
  }
}

#NEAC
for (r in 1:N.NEAC) {
  
  for (t in 1:n) {  
    C8.NEAC.3[t,r] <- Data_nimble$prop_F2[t,r]*C8.NEAC.3.tot[t]
    h8.NEAC.3[t,r] <- C8.NEAC.3[t,r]/(C8.NEAC.3[t,r]+N8.3[t,r+N.NAC])
  }
  
  for (t in 1:(n-1)) {   
    N8.2[t,r+N.NAC]      <- (N8.3[t+1,r+N.NAC]+C8.NEAC.3[t+1,r])/theta8.2.1.NEAC
  }
}


# N8.1
# ----------------------------------------------

for (t in 1:(n-1))
{  
  for (r in 1:N) {
    C8.2[t,r] <- Data_nimble$prop_Gld[t,r]*C8.2.tot[t] 
  }
  for (r in 1:N.NAC) {
    N8.1[t,r] <- (N8.2[t,r]+C8.2[t,r])/theta8.NAC.2
  }
  for (r in (N.NAC+1):N) {
    N8.1[t,r] <- (N8.2[t,r]+C8.2[t,r])/theta8.NEAC.2
  }
  for (r in 1:N) {
    h8.2[t,r] <- C8.2[t,r]/(C8.2[t,r]+N8.2[t,r])
  }
}


# N8
# ----------------------------------------------

#NAC
for (t in 1:(n-1))
{  
  h8.NAC.1[t] <-  C8.NAC.1.tot[t]/(sum(N8.1[t,1:N.NAC])+ C8.NAC.1.tot[t])
  
  for (r in 1:N.NAC) {
    N8[t,r] <- N8.1[t,r] / ((1-h8.NAC.1[t])*theta8.1.NAC)
  }
}

#NEAC
for (t in 1:(n-1))
{  
  for (r in 1:N.NEAC) {
    C8.NEAC.1[t,r] <- Data_nimble$prop_F1.nm[t,r]*C8.NEAC.1.tot[t]
    N8[t,r+N.NAC]      <- (N8.1[t,r+N.NAC]+C8.NEAC.1[t,r])/theta8.1.NEAC
    h8.NEAC.1[t,r] <- C8.NEAC.1[t,r]/(C8.NEAC.1[t,r]+N8.1[t,r+N.NAC])
  }
}


# N5.1
# ----------------------------------------------

for (t in 1:(n-1))
{
  #NAC
  for (r in 1:N.NAC) {
    N5.1[t,r] <- N6[t,r] / theta5.3.NAC
  }
  #NEAC
  for (r in 7:N) {
    N5.1[t,r] <- N6[t,r] / theta5.2.NEAC
  }
}

# N5.1.2
# ----------------------------------------------

for (t in 1:(n-1))
{  
  N5.1.2[t,1]       <- N5.1[t,1]/theta5.2.NAC
  h5.NAC.3.other[t] <-  C5.NAC.3.tot[t]/(sum(N5.1[t,2:6])+ C5.NAC.3.tot[t])
  
  for (r in 2:6) {
    N5.1.2[t,r] <- N5.1[t,r] / ((1-h5.NAC.3.other[t])*theta5.2.NAC)
  }
}  

# N5.1.1
# ----------------------------------------------

for (t in 1:(n-1))
{  
  h5.NAC.2.lab[t]   <-  C5.NAC.2.lab[t]/(N5.1.2[t,1]+C5.NAC.2.lab[t])
  h5.NAC.2.other[t] <-  C5.NAC.2.other[t]/(sum(N5.1.2[t,2:6])+C5.NAC.2.other[t])
  
  N5.1.1[t,1] <- N5.1.2[t,1] + C5.NAC.2.lab[t]
  
  for (r in 2:6) {
    N5.1.1[t,r] <- N5.1.2[t,r] / (1-h5.NAC.2.other[t])
  }
}

# N5 
# ----------------------------------------------

#NAC
for (t in 1:(n-1))
{  
  h5.NAC.1[t] <-  C5.NAC.1.tot[t]/(sum(N5.1.1[t,1:N.NAC])+C5.NAC.1.tot[t])
  
  for (r in 1:N.NAC) {
    N5[t,r] <- N5.1.1[t,r] / ((1-h5.NAC.1[t])*theta5.1.NAC)
  }
}

# NEAC

for (t in 1:(n-1))
{  
  for (r in 1:N.NEAC) {
    C5.NEAC.1[t,r] <- Data_nimble$prop_F1.m[t,r]*C5.NEAC.1.tot[t]
    N5[t,r+N.NAC]      <- (N5.1[t,r+N.NAC]+C5.NEAC.1[t,r])/theta5.1.NEAC
    h5.NEAC.1[t,r] <- C5.NEAC.1[t,r]/(C5.NEAC.1[t,r]+N5.1[t,r+N.NAC])
  }
}



# N4 (dimension [n-1,N] at this stage)
# ----------------------------------------------

N4 <- N5+N8



# theta4 : ratio N5/(N5+N8)
# ----------------------------------------------

for (t in 1:(n-1))
{ 
	for (r in 1:N)
	{
	theta4[t,r] <- N5[t,r] / N4[t,r]
	}
}

# Complete the last year

theta4[n,1:N] <- theta4[(n-1),1:N]



# theta3 - ratio N4 -> N3
# ----------------------------------------------

for (t in 1:(n-2))
{ 
  for (r in 1:N) {
    theta3[t,r] <- N4[t+1,r]/N3.tot[t,r]
  }
}


# Comple the last two years

theta3[(n-1),1:N] <- theta3[(n-2),1:N]
theta3[n,1:N] <- theta3[(n-2),1:N]


# Calculate logit.theta3 and logit.theta4

logit.theta3 <- log(theta3/(1-theta3))
logit.theta4 <- log(theta4/(1-theta4))


#########################################################


# Save variables that must be fixed to reasonnable values
# when simulating from the Nimble model
# Variables saved as a list

Fixed_for_simul <- list(	N1.pr, N2,  
					h.hw.1SW, h.hw.2SW, h5.NAC.1, h5.NEAC.1, h5.NAC.2.other, h5.NAC.2.lab, h5.NAC.3.other,
					h8.NAC.1, h8.NEAC.1, h8.2, h8.NAC.3, h8.NEAC.3, h8.NAC.4.other, h8.NAC.4.lab, h8.NAC.5, 
					logit.theta3, logit.theta4
					# , "M"
					) 

# Attention : variable h8.NAC.5 in the code above correponds to h8.NAC.5.other in the nimble code !!

names <- 			c(	"N1.pr", "N2",
					"h.hw.1SW", "h.hw.2SW", "h5.NAC.1", "h5.NEAC.1", "h5.NAC.2.other", "h5.NAC.2.lab", "h5.NAC.3.other",
					"h8.NAC.1", "h8.NEAC.1", "h8.2", "h8.NAC.3", "h8.NEAC.3", "h8.NAC.4.other", "h8.NAC.4.lab", "h8.NAC.5.other", 
					"logit.theta3", "logit.theta4"
					# , "M"
					) 

names(Fixed_for_simul) <- names

save(Fixed_for_simul, file = "Fixed_for_simul.RData")

# var.to.save <- fixed_for_simul
# rm(list=setdiff(ls(), var.to.save))
# save.image("Fixed_for_SimulNimble.RData")



