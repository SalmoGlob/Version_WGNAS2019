# Forecasting
# The program reads the data and the mcmc draws from the fitting phase,
# needed to integrate out the uncertainty on parameters values
# The life cycle is rewritten in this program
 
# V. - E. Rivot, M. Olmos - 28 March 2019

rm(list=ls(all=TRUE))

library(coda)
library(MASS)
library(tcltk)


# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# TO READ
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------

# Program to run forecast for all SU (24 SU)
# using catches scenarios in Faroes and W. Greenland

# Nb years of projections = n.pred + 2 (n.pred is read in the program)

# First year of the forecast model, t=1 in the prpgram below, 
# correponds to (n-1)=start.year = last year of the MCMC results
# for which all state variables are fitted to data.

# This first year year t=1 is initialized with mcmc draws from previous fitting results
# The same MCMC draws are used for all catches scenarios
# "Projections" really starts at t = 2

# Load data (same files than for fitting)
# ------------------------------

# Load data

load("Data/Const_nimble.RData")
names(Const_nimble)
attach(Const_nimble)

load("Data/Data_nimble.RData")
names(Data_nimble)
attach(Data_nimble)


source("Data/Source_Index.R")
# Contains the following variables (only needed to plot)
regions24
country17
country17Full
colors24
colors17
typepoint24


# Predictions
# ------------------------------

# Preditions are made from start.year  = Last year of the MCMC results for which all state variables
# are fitted to data is n-1 (only 1SW returns of the cohort issuing from the PFA
# year n can be updated by data. Returns of 2SW are not observed yet
# (will be observed yeat n+1 

n.pred <- 4
start.year <- n-1

# Definition of catches scenarios Faroes and W. Greenland
# Catches in tons
# --------------------------------------------------------------------------

# Catches at sea are already observed for t=1 
# (that is year n-1 in the Bayesian life cycle model fitted on the data)
# and t=2 (n = last year in the full data set)

n.scenario.Fa <- 5
n.scenario.WG <- 5
Scenarios.TAC.Fa <- seq(0,250,length.out = n.scenario.Fa)
Scenarios.TAC.WG <- seq(0,100,length.out = n.scenario.WG)

# MCMC draws
# --------------------------------------------------------------------------
# Number of mcmc draws to integrate over parameter and state uncertainty
# Population dynamics x scenarios are all run for all MCMC draws

n.draws <- 100


# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# 
# LOAD MCMC draws from previous fit
# 
# Posterior uncertainty on parameters integrated over MCMC draws 
# MCMC draws for all those variables must be stored in the mcmc results

# logit.theta3, logit.theta4
# tau.theta3, tau.tehta4
# N1, N3, N4, N5, N8, N8.2, N6, N7, N9, N10

# Make use of the function "extract.var.dim1.dim2" and "extract.var.dim1.dim2.dim3"
# Create arrays with generic names "variables.mcmc"
# usually with dim 1 = year, dim 2 = region, and dim.3 = mcmc draws
# in which it is simple to sample in for Monte Carlo integration

load("Results/mcmc_nimble.RData")
# load("Results/mcmc_nimble_Conf0.RData")

niter(mcmc_nimble)
nchain(mcmc_nimble)
nvar(mcmc_nimble)


# Extract a sample of size n.draws from mcmc draws
# library(coda)
# mcmc_nimble <- window(x=mcmc_nimble,start=1,end=n.draws)
# niter(mcmc_nimble)
# nchain(mcmc_nimble)
# nvar(mcmc_nimble)


# Function to extract mcmc draws of 1 particular cell in a 2-dimensional variable 
# var[dim1,dim2]
# Coerce all chains and store in 1 data frame with only one column

extract.var.dim1.dim2 <- function(mcmc.list, var.name, dim1, dim2)
{
  var.mcmc = mcmc.list[,which(varnames(mcmc.list) == paste(var.name,"[",dim1,", ",dim2,"]",sep=""))]
  var.mcmc.tab <- as.data.frame(as.matrix(window(var.mcmc)))
}

# Function to extract mcmc draws of 1 particular cell in a 3-dimensional variable 
# var[dim1,dim2,dim3]
# Coerce all chains and store in 1 data frame with only one column

extract.var.dim1.dim2.dim3 <- function(mcmc.list, var.name, dim1, dim2, dim3)
{
  var.mcmc = mcmc.list[,which(varnames(mcmc.list) == paste(var.name,"[",dim1,", ",dim2,", ",dim3,"]",sep=""))]
  var.mcmc.tab <- as.data.frame(as.matrix(window(var.mcmc)))
}



var.name = "logit.theta3"
var.mcmc.array <- array(data=NA,dim=c(n,N,n.draws))
for(y in 1:n){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
logit.theta3.mcmc <- var.mcmc.array



var.name = "logit.theta4"
var.mcmc.array <- array(data=NA,dim=c(n,N,n.draws))
for(y in 1:n){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
logit.theta4.mcmc <- var.mcmc.array



var.name = "tau.theta3"
var.mcmc.array <- array(data=NA,dim=c(N,N,n.draws))
for(y in 1:N){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
tau.theta3.mcmc <- var.mcmc.array

var.name = "tau.theta4"
var.mcmc.array <- array(data=NA,dim=c(N,N,n.draws))
for(y in 1:N){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
tau.theta4.mcmc <- var.mcmc.array


# Get variance from precision matrix

var.theta3.mcmc <- array(data=NA,dim=c(N,N,n.draws))
for(i in 1:n.draws){
  var.theta3.mcmc[1:N,1:N,i] <- solve(tau.theta3.mcmc[1:N,1:N,i])
}

var.theta4.mcmc <- array(data=NA,dim=c(N,N,n.draws))
for(i in 1:n.draws){
  var.theta4.mcmc[1:N,1:N,i] <- solve(tau.theta4.mcmc[1:N,1:N,i])
}


# N1 (Total smolt per cohort)

var.name = "N1"
var.mcmc.array <- array(data=NA,dim=c((n-1),N,n.draws))
for(y in 1:(n-1)){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
N1.mcmc <- var.mcmc.array


# N3 (Smolts)

var.name = "N3"
var.mcmc.array <- array(data=NA,dim=c(n+nSm,nSm,N,n.draws))
for(k in 1:nSm){
  for(y in 1:(n+k)){
    for(z in 1:N){
      var.mcmc.array[y,k,z,1:n.draws] <- extract.var.dim1.dim2.dim3(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = k, dim3 = z)[1:n.draws,1]
    }}}
N3.mcmc <- var.mcmc.array


var.name = "N4"
var.mcmc.array <- array(data=NA,dim=c(n,N,n.draws))
for(y in 1:n){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
N4.mcmc <- var.mcmc.array


var.name = "N5"
var.mcmc.array <- array(data=NA,dim=c(n,N,n.draws))
for(y in 1:n){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
N5.mcmc <- var.mcmc.array


var.name = "N8"
var.mcmc.array <- array(data=NA,dim=c(n,N,n.draws))
for(y in 1:n){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
N8.mcmc <- var.mcmc.array


var.name = "N8.2"
var.mcmc.array <- array(data=NA,dim=c((n-1),N,n.draws))
for(y in 1:(n-1)){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
N8.2.mcmc <- var.mcmc.array


var.name = "N6"
var.mcmc.array <- array(data=NA,dim=c(n-1,N,n.draws))
for(y in 1:(n-1)){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
N6.mcmc <- var.mcmc.array


var.name = "N9"
var.mcmc.array <- array(data=NA,dim=c(n,N,n.draws))
for(y in 1:n){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
N9.mcmc <- var.mcmc.array


var.name = "N7"
var.mcmc.array <- array(data=NA,dim=c((n-1),N,n.draws))
for(y in 1:(n-1)){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
N7.mcmc <- var.mcmc.array


var.name = "N10"
var.mcmc.array <- array(data=NA,dim=c(n,N,n.draws))
for(y in 1:n){
  for(z in 1:N){
    var.mcmc.array[y,z,1:n.draws] <- extract.var.dim1.dim2(mcmc.list = mcmc_nimble, var.name = var.name, dim1 = y, dim2 = z)[1:n.draws,1]
  }}
N10.mcmc <- var.mcmc.array



# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# Create variables to store forecasting results - named "XXX.f"
# Dimensions = [years of prediction,region,n.scenario.Fa,n.scenario.WG,n.draws]
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------

logit.theta3.f	<- theta3.f <- array(data=NA, dim = c(n.pred+2,N,n.scenario.Fa,n.scenario.WG , n.draws))
logit.theta4.f	<- theta4.f <- array(data=NA, dim = c(n.pred+2,N,n.scenario.Fa,n.scenario.WG , n.draws))
N1.f <- N2.f 	<- array(data=NA, dim = c(n.pred+1,N,n.scenario.Fa,n.scenario.WG , n.draws)) 
N3.f 			<- array(data=NA, dim = c(n.pred+1+nSm+1,nSm,N,n.scenario.Fa,n.scenario.WG , n.draws))
N3.tot.f		<- array(data=NA, dim = c(n.pred+1,N,n.scenario.Fa,n.scenario.WG , n.draws))
N4.f 			<- array(data=NA, dim = c(n.pred+2,N,n.scenario.Fa,n.scenario.WG , n.draws))
N5.f <- N8.f	<- array(data=NA, dim = c(n.pred+2,N,n.scenario.Fa,n.scenario.WG , n.draws))
N6.f			<- array(data=NA, dim = c(n.pred+2,N,n.scenario.Fa,n.scenario.WG , n.draws))
N8.1.f <- N8.2.f <- N9.f <- array(data=NA, dim = c(n.pred+2,N,n.scenario.Fa,n.scenario.WG , n.draws))
N7.f <- N10.f	<- array(data=NA, dim = c(n.pred+2,N,n.scenario.Fa,n.scenario.WG , n.draws))



# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
#                         Loop on catch scenarios
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------

# Indice scenario

ind1_min = 1
ind1_max = n.scenario.Fa*n.scenario.WG


# Indice n.draws (integration of parameter uncertainty over MCMC draws)

mcmc_min = 1
mcmc_max = n.draws

# Defining the progress bar on the index of MCMC draws 

pb <- tkProgressBar(width = 600, min = mcmc_min, max = mcmc_max, initial = mcmc_min)

# Open loop on scenario Faroes and Greenland

for (sFa in 1:n.scenario.Fa)
{
   for (sWG in 1:n.scenario.WG)
   {
        
	# -----------------------------------------------------------------
    #
	# Define catches of marine mixed fisheries for each of the scenario
    #
	# -----------------------------------------------------------------
    
    # Catches Faroes (concern NEAC only)
    # ------------------------------------------------
    # CF1.m.p, CF1.nm.p, CF2.p are vector of length n.pred+2
    # Later in the model, will be shared among SU given known proportions (in the data)
    
    # Total TAC Faroes in kg
    
    TAC.Faroes <- Scenarios.TAC.Fa[sFa]*1000
        
    # Load the function that convert catch in tons into number of fish that really die
    # in the three different categories
    
    source("Function/function.convert.scenario.Faroes.R")
    
    # Create vector of catches given the quotas
    # The first two years are the observed data ; the other years are scenarios
    
    CF1.m.p <- c(exp(log.CF1.m.m[start.year]),exp(log.CF1.m.m[n]))
    CF1.m.p <-  c(CF1.m.p , rep(function.convert.scenario.Faroes(TAC.in.kg = TAC.Faroes)$CF1.m.p,  times = n.pred))
    
    CF1.nm.p <- c(exp(log.CF1.nm.m[start.year]),exp(log.CF1.nm.m[n]))
    CF1.nm.p <- c(CF1.nm.p , rep(function.convert.scenario.Faroes(TAC.in.kg = TAC.Faroes)$CF1.nm.p, times = n.pred))
    
    CF2.p <- c(exp(log.CF2.m[start.year]),exp(log.CF2.m[n]))
    CF2.p <- c(CF2.p , rep(function.convert.scenario.Faroes(TAC.in.kg = TAC.Faroes)$CF2.p, times = n.pred))
  
    
    # Catches Greenland (concern NAC and NEAC)
    # -------------------------------------------------
    
    # CG2.p is a vector of length n.pred+2
    # Later in the model, will be shared among SU given known proportions (in the data)
    
    # TAC West Greenland in kg
    
    TAC.WG <- Scenarios.TAC.WG[sWG]*1000
    
    # Load the function that convert catch in tons into number of fish that really die
    
    source("Function/function.convert.scenario.WG.R")
    
    # Create vector of catches given the quotas
    # The first two years are the observed data ; the 3 other years are scenarios
    
    CG2.p <- c(exp(log.CG2.m[start.year]), exp(log.CG2.m[n]))
    CG2.p <- c(CG2.p, rep(function.convert.scenario.WG(TAC.in.kg = TAC.WG)$CG2.p, times = n.pred))
    
    
    # Proportion to share catches at sea among all SU
	# -----------------------------------------------------
	# For Greenland and Faroes, those proportions are considered known
	# Fixed to the mean of the last five years of data = from n-4 to n
	# For other fisheries, those proportions are calculated from the relative proportions
	# of abundance (PFA stage or abundance just before the fishery) to mimic the fact that
	# harvest is proportional to abundance + other specific hypotheses 
        
    # Faroes (NEAC only) 
    # ------------------
	
    prop_F1.m.p <- apply(prop_F1.m[(n-4):n,], 2, FUN=mean)
    prop_F1.nm.p <- apply(prop_F1.nm[(n-4):n,], 2, FUN=mean)     
    prop_F2.p <- apply(prop_F2[(n-4):n,], 2, FUN=mean)
    
    # Greenland (concern NAC + NEAC)
    # ------------------------------
	
    prop_Gld.p <- apply(prop_Gld[(n-4):n,], 2, FUN=mean)
        
    # Other Catches NAC - MATURING
    # ----------------------------
    
    # C1.Nf.3_7.m.p
    # Catches Newfoundland SFA 3-7
    # Shared among SU in NAC given relative proportion of PFA in all SU in NAC
	# The relative proportion of PFA is a variable calculated at each step in the model 
    
    C1.Nf.3_7.m.p <- rep(0,times=(n.pred+2))
    
    # C1.LbNf.m.p
    # Catches Labrador - Newfoundland
    # Known proportion for Lab. (Hyp. = same proportion than for 2SW fish (see below))
    # + Shared among SU in NAC given relative proportion of PFA in all SU except Labrador
    
    C1.LbNf.m.p <- rep(0,times=(n.pred+2))
    
    # C1.SPM.p
    # Catches St Pierre-Miquelon
    # 0 for Labrador
    # + Shared among SU in NAC given relative proportion of PFA in all SU except Labrador
    
    C1.SPM.p <- rep(0,times=(n.pred+2))
        
    # Other Catches NAC - NON MATURING
    # --------------------------------
    
    # C1.nm.LbNf.m.p
    # Catches Labrador - Newfoundland
    # Shared among SU in NAC given relative proportion of PFA
    
    C1.nm.LbNf.m.p <- rep(0,times=(n.pred+2))
    
    # C2.Nf.3_7.m.p
    # Catches Newfoundland SFA 3-7
    # Shared among SU in NAC given relative proportion of PFA
    
    C2.Nf.3_7.m.p <- rep(0,times=(n.pred+2))
    
    # C2.LbNf.m.p
    # Catches Labrador - Newfoundland
    # Known proportion for Lab.
    # + Shared among SU in NAC given relative proportion of PFA in all SU except Labrador
    # pLabi ~ uniform (0.6, 0.8)  for i = 1971 to 1997
    # pLabi ~ uniform (0.9, 1.0) for i = 1998 to present
    
    C2.LbNf.m.p <- rep(0,times=(n.pred+2))
    
    # C2.SPM.p
    # 0 for Labrador
    # + Shared among SU in NAC given relative proportion of PFA in all SU except Labrador
    
    C2.SPM.p <- rep(0,times=(n.pred+2))
    
    
    # ----------------------------------------------------
    #
	# Define Homewater catches for each scenario
    # hw.C1sw.p, hw.C2sw.p and catches of delayed spawners
	#
    # ----------------------------------------------------
    
    # Scenarios 
    
	# Homewater catches = Observed catches for the first two years start.year and (start.year+1)=n
    # Then catches = mean of 5 last years for the following years 
    
    hw.C1SW.p <- exp(log.hwC1SW.m[start.year:(start.year+1),])
    for (i in 1:(n.pred+1)){ hw.C1SW.p <- rbind(hw.C1SW.p,apply(exp(log.hwC1SW.m[(n-4):n,]),2,mean)) }
    
    hw.C2SW.p <- exp(log.hwC2SW.m[start.year:((start.year+1)),])
    for (i in 1:(n.pred+1)){ hw.C2SW.p <- rbind(hw.C2SW.p,apply(exp(log.hwC2SW.m[(n-4):n,]),2,mean))}
    
	# Proportions of delayed spawners and catches of delayed spawners
	
    prop.delSp.1SW.p <- prop.delSp.1SW[start.year:(start.year+1),]
    for (i in 1:(n.pred+1)){ prop.delSp.1SW.p <- rbind(prop.delSp.1SW.p,apply(prop.delSp.1SW[(n-4):n,],2,mean)) }
	
	prop.delSp.2SW.p <- prop.delSp.2SW[start.year:(start.year+1),]
    for (i in 1:(n.pred+1)){ prop.delSp.2SW.p <- rbind(prop.delSp.2SW.p,apply(prop.delSp.2SW[(n-4):n,],2,mean)) }

	# Catches delayed spawners
 
	Chw.1SW.delSp.p <- exp(log.Chw.1SW.delSp.m[start.year:(start.year+1),])
    for (i in 1:(n.pred+1)){ Chw.1SW.delSp.p <- rbind(Chw.1SW.delSp.p,apply(exp(log.Chw.1SW.delSp.m[(n-4):n,]),2,mean)) }	

	Chw.2SW.delSp.p <- exp(log.Chw.2SW.delSp.m[start.year:(start.year+1),])
    for (i in 1:(n.pred+1)){ Chw.2SW.delSp.p <- rbind(Chw.2SW.delSp.p,apply(exp(log.Chw.2SW.delSp.m[(n-4):n,]),2,mean)) }	
	
	# Stocking
	
	Stocking.2SW.p <- Stocking.2SW[start.year:(start.year+1),]
    for (i in 1:(n.pred+1)){ Stocking.2SW.p <- rbind(Stocking.2SW.p,apply(Stocking.2SW[(n-4):n,],2,mean)) }

    # --------------------------------------------------------------------------
    # --------------------------------------------------------------------------
    # 
	# Loop on mcmc draws to integrate parameter uncertainty
    # within each scenario
    #
	# --------------------------------------------------------------------------
    # --------------------------------------------------------------------------
        
    # Progress bar on MCMC draws and for each scenario
    # -----------------------------------------------------
    
    for (i in 1:n.draws)
    {
      
	setTkProgressBar(pb,i,label = paste("Integrating over ",n.draws," MCMC draws - Scenario Fa= ",sFa,"/",n.scenario.Fa," - WG= ",sWG,"/",n.scenario.WG))
      
    # --------------------------------------------------------------------------
    # --------------------------------------------------------------------------
    #                    Population Dynamic model
	#        Will change at each iteration (scenario X MCMC draws)
    # --------------------------------------------------------------------------
    # --------------------------------------------------------------------------
      
    # --------------------------------------------------------------------------
    # Create variable to store the projection for each MC draw
	# Content of those variable will change at each iteration
    # --------------------------------------------------------------------------
      
      logit.theta3 <- theta3 <- array(data=NA, dim = c(n.pred+2,N))
      logit.theta4 <- theta4 <- array(data=NA, dim = c(n.pred+2,N))
      
      N7 <- N10 <- array(data=NA, dim = c(n.pred+1,N))
      
      N1 <- array(data=NA, dim = c(n.pred+1,N)) 
      N2 <- array(data=NA, dim = c(n.pred+1,N))
      
      N3 <- array(data=NA, dim = c(n.pred+1+nSm+1,nSm,N))
      
      N3.tot <- array(data=NA, dim = c(n.pred+1,N))
      
      N4 <- array(data=NA, dim = c(n.pred+2,N))
      
      N5 <- array(data=NA, dim = c(n.pred+2,N))
      N8 <- array(data=NA, dim = c(n.pred+2,N))
      
      N6 <- array(data=NA, dim = c(n.pred+2,N))
      
      N8.1 <- array(data=NA, dim = c(n.pred+2,N))
      N8.2 <- array(data=NA, dim = c(n.pred+2,N))
      N9 <- array(data=NA, dim = c(n.pred+2,N))
      
      N7 <- array(data=NA, dim = c(n.pred+2,N))
      N10 <- array(data=NA, dim = c(n.pred+2,N))
      
      # Proportion of each stock units at PFA stage (will be used to share proportions
      
      prop.PFA.NAC.all <- array(data=NA, dim = c(n.pred+2,N.NAC))
      prop.PFA.NAC.noLab <- array(data=NA, dim = c(n.pred+2,N.NAC))
      
      prop.PFAnm.NAC.all <- array(data=NA, dim = c(n.pred+2,N.NAC))
      prop.PFAnm.NAC.noLab <- array(data=NA, dim = c(n.pred+2,N.NAC))
      
      # Proportion to share catches among stock units in NAC 
      # Mature fish
      
      prop.C1.Nf.3_7.m.p <- array(data=NA, dim = c(n.pred+2,N.NAC))
      prop.C1.LbNf.m.p <- array(data=NA, dim = c(n.pred+2,N.NAC))
      prop.C1.SPM.p <- array(data=NA, dim = c(n.pred+2,N.NAC))
      
      # Non mature fish
      
      prop.C1.nm.LbNf.m.p <- array(data=NA, dim = c(n.pred+2,N.NAC))	
      prop.C2.Nf.3_7.m.p <- array(data=NA, dim = c(n.pred+2,N.NAC))	
      prop.C2.LbNf.m.p <- array(data=NA, dim = c(n.pred+2,N.NAC))
      prop.C2.SPM.p <- array(data=NA, dim = c(n.pred+2,N.NAC))
      
      # ---------------------------------------------------------------
      # Initilization for the first years with mcmc draws
      # ---------------------------------------------------------------
      
      # Inits first year with last year of mcmc results
      
      N4[1,1:N] <- N4.mcmc[start.year,1:N,i]
      
      N5[1,1:N] <- N5.mcmc[start.year,1:N,i]
      
      # Proportion of NON maturing PFA for each SU in NAC area
      # Labrador = r = 1
      
      prop.PFAnm.NAC.all[1,1:N.NAC] <- N5[1,1:N.NAC]/sum(N5[1,1:N.NAC])
      
      # Proportion sum to 1 without Labrador
      # Starts at r = 2

      prop.PFAnm.NAC.noLab[1,2:N.NAC] <- N5[1,2:N.NAC]/sum(N5[1,2:N.NAC])
      
      N8[1,1:N] <- N8.mcmc[start.year,1:N,i]
      
      N6[1,1:N] <- N6.mcmc[start.year,1:N,i]
      
      N7[1,1:N] <- N7.mcmc[start.year,1:N,i]
      
      N8.2[1,1:N] <- N8.2.mcmc[start.year,1:N,i]
      
      N9[1,1:N] <- N9.mcmc[start.year,1:N,i]
      
      N10[1,1:N] <- N10.mcmc[start.year,1:N,i]
      
      # Initialisation of all N3 that are not generated in the 
      # forecasting procedure
      
      for (k in 1:nSm)
      {
        N3[1,k,1:N] <- N3.mcmc[start.year,k,1:N,i]
        
        for (kk in k:nSm)
        {
          N3[1+k,kk,1:N] <- N3.mcmc[start.year+k,kk,1:N,i]
        }
      }
      
      
      # Post-smolts survival theta3 : N3.tot[t] --> N4[t+1]
      # --------------------------------------------------------
      
      # Var-Covar of random walks in theta3
      # ----------------------------------------------
      
      var.theta3 <- var.theta3.mcmc[1:N,1:N,i]
      
      # Inits first year with last year of mcmc results 
      
      logit.theta3[1,1:N] <- logit.theta3.mcmc[start.year,1:N,i]
      theta3[1, 1:N] <- exp(logit.theta3[1, 1:N]) / (1+exp(logit.theta3[1, 1:N]))
      
      for (t in 1:(n.pred+1))
      {
        logit.theta3[t+1, 1:N] <- mvrnorm(n=1, mu=logit.theta3[t,1:N], Sigma = var.theta3, tol = 1e-6, empirical = FALSE, EISPACK = FALSE)
        theta3[t+1, 1:N] <- exp(logit.theta3[t+1, 1:N]) / (1+exp(logit.theta3[t+1, 1:N]))
      }
      
      
      # Probability early maturing PFA N4[t] --> N5[t] + N8[t]
      # ---------------------------------------------------------
      
      # Var-Covar of random walks in theta4
      # ----------------------------------------------
      
      var.theta4 <- var.theta4.mcmc[1:N,1:N,i]
      
      # Inits first year with last year of mcmc results
      
      logit.theta4[1,1:N] <- logit.theta4.mcmc[start.year,1:N,i]
      theta4[1, 1:N] <- exp(logit.theta4[1, 1:N]) / (1+exp(logit.theta4[1, 1:N]))
      
      for (t in 1:(n.pred+1))
      {
        logit.theta4[t+1, 1:N] <- mvrnorm(n=1, mu=logit.theta4[t,1:N], Sigma = var.theta4, tol = 1e-6, empirical = FALSE, EISPACK = FALSE)
        theta4[t+1, 1:N] <- exp(logit.theta4[t+1, 1:N]) / (1+exp(logit.theta4[t+1, 1:N]))
      }
      
      # ---------------------------------------------------------------
      # Fixed parameters and informative priors
      # ---------------------------------------------------------------
      
      # General dummy noise
      # All demographic transitions are modeled using logNormal process noise
      # with a variance arbitrarily fixed to a very low value corresponding 
      # to a coefficient of variation CV.dummy (read in the data set = 0.01)
      sigma.dummy <- (log(CV.dummy*CV.dummy + 1))^0.5
      
      # Survival eggs --> Total smolts
      # theta1 in a very informative logNormal prior
      # E.theta1 and CV.theta1 read in the data
      sigma.theta1 <- (log(CV.theta1*CV.theta1 + 1))^0.5
      
      # LogNormal random noise about the average proportion of smolts ages
      # CV.psm in the data
      sigma.psm <- (log(CV.psm*CV.psm + 1))^0.5
      
      # Natural mortality
      # Parameterized as monthly mortality rate M
      # ~LogNormal with E.M and CV.M read in the data set
      # Considered constant after PFA
      # Is applied for all stages between PFA and returns
      # using duration deltat.
      
      sigma2.M <- log(CV.M*CV.M + 1)
      tau.log.M <- 1/sigma2.M	
      E.log.M <- log(E.M) - 0.5/tau.log.M
      sigma.M <- sigma2.M^0.5
      
      M <- rlnorm(n=1, meanlog = E.log.M, sdlog = sigma.M)
      
      # Proportion of smolts ages * N.Sample
      
      mu.psm <- p.smolt*N.Sample.sm + 0.01
      
      
      
      # -----------------------------------------------------------
      #                            Loop on t
      #                        and Stock Units r
      # -----------------------------------------------------------
      
      for (t in 1:(n.pred+1))
      {
        
        
        # N1 : Number of eggs from spawners
        # ---------------------------------
        
        N1[t,1:N] <- N7[t,1:N]*eggs[1,1:N] + N10[t,1:N]*eggs[2,1:N]
        
        
        # N2 : Eggs --> total Smolts per cohorts (survival known and fixed to E.theta1)
        # -----------------------------------------------------------------------------
        
        N2[t,1:N] <- rlnorm(n=N, meanlog = log(N1[t,1:N]*E.theta1), sdlog = sigma.theta1)
        
        
        # N3 :  Smolts distribution  by age class : 6 age classes 
        # -------------------------------------------------------
        
        # Dirichlet Informative prior for the proportion of smolts ages
        # Information equivalent to the one gained with a sample size = N.Sample
        # To improve computationnal speed, the Dirichlet is written with Gamma
        
        psm.stoch <- array(data=NA, dim = c(nSm,N))
        prop_gamma <- array(data=NA, dim = c(nSm,N))
        
        for (r in 1:N)
        {
        # psm.stoch[t,1:nSm,r] ~ ddirich(mu.psm[1:nSm,r])
        # psm.stoch[1:nSm,r] <- rep(1/nSm,times=6)	
        prop_gamma[1:nSm,r] <- rgamma(n=nSm, shape = mu.psm[1:nSm,r], rate = 1)
        psm.stoch[1:nSm,r] <- prop_gamma[1:nSm,r] / sum(prop_gamma[1:nSm,r])
        }
        
        # Proportions with logNormal random noise
        for (k in 1:nSm)
        {
           N3[t+1+k,k,1:N] <- rlnorm(n=N, meanlog = log(psm.stoch[k,1:N]*N2[t,1:N]), sdlog = sigma.psm)
        }
        
        # Total smolt migrating each year t
        
        N3.tot[t,1:N] <- apply(N3[t,1:nSm,1:N], MARGIN = c(2), FUN=sum)
        
        
        # N4 : Smolt --> PFA (N4)
        # From N3.tot and survival theta3
        # --------------------------------
        
        # Post-smolts survival theta3 : N3.tot[t] --> N4[t+1]
        # ---------------------------------------------------
        
        N4[t+1,1:N] <- rlnorm(n=N, meanlog = log(theta3[t,1:N]*N3.tot[t,1:N]), sdlog = sigma.dummy)
        
        #  N5 : PFA maturing during the fisrt year at sea
        #  From N4 (PFA) and theta4 = proba maturing the first year at sea
        #  ---------------------------------------------------------------
        
        N5[t+1,1:N] <- rlnorm(n=N, meanlog = log(N4[t+1,1:N] * theta4[t+1,1:N]), sdlog = sigma.dummy)
        
        #  N8 : PFA non maturing after the fisrt year at sea
        #  From N4 (PFA) and (1-theta4)
        #  --------------------------------------------------
        
        N8[t+1,1:N] <- rlnorm(n=N, meanlog = log(N4[t+1,1:N] * (1-theta4[t+1,1:N])), sdlog = sigma.dummy)
        
        # Proportion of PFA by SU
        # ---------------------------------------------------
        
        # Proportion MATURING PFA
        # -----------------------
        
        # Proportion for each 6 SU in NAC area
        
        prop.PFA.NAC.all[t+1,1:N.NAC] <- N4[t+1,1:N.NAC]/sum(N4[t+1,1:N.NAC])
        
        # Proportion summing to 1 without Labrador
        # Labrador = r = 1
        
        prop.PFA.NAC.noLab[t+1,2:N.NAC] <- N4[t+1,2:N.NAC]/sum(N4[t+1,2:N.NAC])
        
        # Proportion of NON maturing PFA
        # Note that will be needed also for t = 1
        # Filled above with N5[t=1]	
        # -----------------------
        
        # Proportion for each of the 6 SU in NAC
        
        prop.PFAnm.NAC.all[t+1,1:N.NAC] <- N5[t+1,1:N.NAC]/sum(N5[t+1,1:N.NAC])
        
        # Proportion sum to 1 without Labrador
		# Labrador = r =1
        
        prop.PFAnm.NAC.noLab[t+1,2:N.NAC] <- N5[t+1,2:N.NAC]/sum(N5[t+1,2:N.NAC])
        
        
        # PFA to returns as MATURING FISH (N6)
        # -------------------------------------
        
        # NAC - LB/NF and SPM fisheries and returns to N6
        # -----------------------------------------------
        
        # Natural mortality between sequential fisheries
        
        # PFA to Labrador 1SWm
        theta5.1.NAC <- exp(-deltat.5.1.NAC*M)
        
        # Labrador -> SPM
        theta5.2.NAC <- exp(-deltat.5.2.NAC*M)
        
        # SPM ->  Returns (N6)
        # theta6.NAC <- exp(-deltat.6.NAC*M)
		theta5.3.NAC <- exp(-deltat.5.3.NAC*M)
		        
        # Total survival PFA --> Returns N6 (for predictions only)
        theta6.tot.NAC <- theta5.1.NAC * theta5.2.NAC * theta5.3.NAC	
        
                
        # Catches Newfoundland SFA 3-7 - Shared in proportion to PFA maturing
        # C1.Nf.3_7.m.p
        prop.C1.Nf.3_7.m.p[t+1,1:N.NAC] <- prop.PFA.NAC.all[t+1,1:N.NAC]
        
                
        # Catches Labrador - Newfoundland	
        # C1.LbNf.m.p
        # Known proportion for Lab. Hypothesis : same as for 2SW
        # ~ Unif(0.9,1) --> Mean = 0.95 From the PFA forecasting model - Pr?vost and Chaput 2012
        # Shared in proportion to the PFA for the 5 other SU	
        
        prop.C1.LbNf.m.Labrador <- runif(0.9,1,n=1)
        prop.C1.LbNf.m.p[t+1,1] <- prop.C1.LbNf.m.Labrador
        prop.C1.LbNf.m.p[t+1,2:N.NAC] <- (1-prop.C1.LbNf.m.Labrador) * prop.PFA.NAC.noLab[t+1,2:N.NAC]
        
        
        # Catches St Pierre-Miquelon	
        # C1.SPM.p
        # 0 for Labrador - Shared in proportion to the PFA for the 5 other SU
        
        prop.C1.SPM.p[t+1,2:N.NAC] <- prop.PFA.NAC.noLab[t+1,2:N.NAC]
        prop.C1.SPM.p[t+1,1] <- 0
        
        
        # Catches at sea (Scenario of catches .p in the data)
        
        N6[t+1,1:N.NAC] <- pmax(
          (N5[t+1,1:N.NAC] 
           - C1.Nf.3_7.m.p[t+1] * prop.C1.Nf.3_7.m.p[t+1,1:N.NAC]
           - C1.LbNf.m.p[t+1] * prop.C1.LbNf.m.p[t+1,1:N.NAC]
           - C1.SPM.p[t+1] * prop.C1.SPM.p[t+1,1:N.NAC]) * theta6.tot.NAC, 1)
        
                
        # S.NEAC - Faroes fisheries and returns to N6
        # -------------------------------------------
        
        # Note that indice for stock unit is N.NAC+r for variables N5 and N6
        
        # Natural mortality between sequential fisheries
        
        # PFA -> Faroes m
        # theta5.NEAC <- exp(-M*deltat.5.1.NEAC)
        theta5.1.NEAC <- exp(-M*deltat.5.1.NEAC)
		
        # Faroes  -> returns
        # theta6.NEAC <- exp(-M*(deltat.6.NEAC))
        theta5.2.NEAC <- exp(-M*(deltat.5.2.NEAC))
		
        # Total Survival from PFA to returns (N6)
        theta6.tot.NEAC <- theta5.1.NEAC*theta5.2.NEAC
        
        
        # Catches at sea (Scenario of catches .p in the data)
        
        N6[t+1,(N.NAC+1):N] <- pmax((N5[t+1,(N.NAC+1):N]
                                     - CF1.m.p[t+1] * prop_F1.m.p[1:N.NEAC]) * theta6.tot.NEAC, 1)
        
                
        # PFA to returns as NON MATURING FISH (N9)
        # ------------------------------------------------------------------------
        
        # Catches NAC - NON MATURING
        # --------------------------
        
        # Catches Labrador - Newfoundland - Will be shared in proportion to PFA non mat
        # C1.nm.LbNf.m.p
        
        prop.C1.nm.LbNf.m.p[t+1,1:N.NAC] <- prop.PFAnm.NAC.all[t+1,1:N.NAC]
        
        
        # Catches Newfoundland SFA 3-7 - Will be shared in proportion to PFA non mat
        # C2.Nf.3_7.m.p
        # Note that will be also needed for t=1
        
        prop.C2.Nf.3_7.m.p[t,1:N.NAC] <- prop.PFAnm.NAC.all[t,1:N.NAC]
        
        
        # Catches Labrador - Newfoundland
        # C2.LbNf.m.p
        # Known for labrador ~ Unif(0.9,1) ; From the PFA forecasting model - Pr?vost and Chaput 2012
        # Shared in proportion to PFA non mat. for the 5 other ones
        
        prop.C2.LbNf.m.Labrador <- runif(0.9,1,n=1)
        prop.C2.LbNf.m.p[t,1] <- prop.C2.LbNf.m.Labrador	
        prop.C2.LbNf.m.p[t,2:N.NAC] <- (1-prop.C2.LbNf.m.Labrador) * prop.PFAnm.NAC.noLab[t,2:N.NAC]
        
        
        # Catches St Pierre-Miquelon
        # C2.SPM.p
        # 0 for Labrador - Will be shared in proportion to PFA non mat. for the 5 other ones
        
        prop.C2.SPM.p[t,2:N.NAC] <- prop.PFAnm.NAC.noLab[t,2:N.NAC]
        prop.C2.SPM.p[t,1] <- 0
        
        
        # PFA --> just before Greenland fisheries
        # N8 --> N8.1
        # -------------------------------------
        
        # NAC
        # PFA --> LBandNF fisheries on 1SW non mature 
        # Harvest rate h8.NAC.1
        # Survival theta8.NAC.1
        # ------------------------------------------------------------------------
        
        # Survival rate
        
        theta8.1.NAC <- exp(-M * deltat.8.1.NAC)
        
        # Catches
        
        N8.1[t+1,1:N.NAC] <- pmax((N8[t+1,1:N.NAC] - C1.nm.LbNf.m.p[t+1] * prop.C1.nm.LbNf.m.p[t+1,1:N.NAC]) * theta8.1.NAC , 1)
        
        
        # S.NEAC
        # Faroes fisheries on non mature fish 1SWnm
        # Survival rate theta8.NEAC.1
        # Harvest rate h8.NEAC.1
        # ------------------------------------------------------------------------
        
        # Survival rate
        
        theta8.1.NEAC <- exp(-M*(deltat.8.1.NEAC))
        
        # Catches
        
        N8.1[t+1,(N.NAC+1):N] <- pmax((N8[t+1,(N.NAC+1):N] - CF1.nm.p[t+1] * prop_F1.nm.p[1:N.NEAC]) * theta8.1.NEAC , 1)
        
        
        # Greenland Fisheries - NAC + S.NEAC
        # N8.1 --> N8.2
        # -------------------------------------------------------------------------
        
		# Survival rate before Greenland Fishery - theta8.2[r]
		# calculated with deltat.8.2.NAC and deltat.8.2.NEAC
		# NAC : Labrador -> Greenland
		# NEAC : Faroes  -> Greenland	
		
		theta8.2 <-rep(NA,N) 
		for (r in 1:N.NAC)
		{
		theta8.2[r] <- 	exp(-M * (deltat.8.2.NAC))
		}
	
		for (r in 1:N.NEAC)
		{
		theta8.2[N.NAC+r] <- exp(-M * (deltat.8.2.NEAC))
		}
		
		# catches
        
        N8.2[t+1,1:N] <- pmax( theta8.2 * N8.1[t+1,1:N] - CG2.p[t+1] * prop_Gld.p[1:N] , 1)
        
        
        # AFTER Greenland Fisheries
        # From N8.2 --> N9 = returns as 2SW fish
        # t becomes t+1
        # -------------------------------------------------------------------------
	
        # NAC
        # Sequential fisheries LB/NF and SPM
        # ----------------------------------
        
		# Survival rates
		# Greenland -> Labrador/NF 2SW
		theta8.2.1.NAC <- exp(-M * deltat.8.2.1.NAC)
		# Labrador -> SPM 2SW
		theta8.2.2.NAC <- exp(-M * deltat.8.2.2.NAC)
		# SPM -> returns 2SW
		theta8.2.3.NAC <- exp(-M * deltat.8.2.3.NAC)
	
        # Total survival rate
        
        theta9.tot.NAC <- theta8.2.1.NAC*theta8.2.2.NAC*theta8.2.3.NAC
        
        # Catches and survival
        
        N9[t+1,1:N.NAC] <- pmax((N8.2[t,1:N.NAC] 
                                 - C2.Nf.3_7.m.p[t+1] * prop.C2.Nf.3_7.m.p[t,1:N.NAC]
                                 - C2.LbNf.m.p[t+1] * prop.C2.LbNf.m.p[t,1:N.NAC]
                                 - C2.SPM.p[t+1] * prop.C2.SPM.p[t,1:N.NAC]) * theta9.tot.NAC, 1)
        
        # NEAC
        # Faroes 2SW fisheries and return
        # ----------------------------------
        
		# Survival rates
		# Greenland -> Faroes 2SW
		theta8.2.1.NEAC <- exp(-M * (deltat.8.2.1.NEAC))
		# Faroes -> Returns
		theta8.2.2.NEAC <- exp(-M * (deltat.8.2.2.NEAC))
        
        # Total survival rate 
        theta9.tot.NEAC <- theta8.2.1.NEAC*theta8.2.2.NEAC
        
        # Catches and survival	
        N9[t+1,(N.NAC+1):N] <- pmax(( N8.2[t,(N.NAC+1):N] - CF2.p[t+1] * prop_F2.p[1:N.NEAC]) * theta9.tot.NEAC, 1)
        
        
        # Spawners = returns - Homewater catches
        # Scenario of catches in the data (hw.C1sw.p) & (hw.C2sw.p)
        # ---------------------------------------------------------
        
        #N7[t+1,1:N] <- pmax( N6[t+1,1:N] - hw.C1SW.p[t+1,1:N], 1)
        #N10[t+1,1:N] <- pmax( N9[t+1,1:N] - hw.C2SW.p[t+1,1:N], 1)
        
        N7[t+1,1:N] <- pmax( (N6[t+1,1:N] - hw.C1SW.p[t+1,1:N])*(1 - prop.delSp.1SW.p[t+1,r]) + (N6[t,1:N] - hw.C1SW.p[t,1:N])*prop.delSp.1SW[t,r] - Chw.1SW.delSp.p[t+1,r], 1)
        N10[t+1,1:N] <- pmax( (N9[t+1,1:N] - hw.C2SW.p[t+1,1:N])*(1 - prop.delSp.2SW.p[t+1,r]) + (N9[t,1:N] - hw.C2SW.p[t,1:N])*prop.delSp.2SW[t,r] - Chw.2SW.delSp.p[t+1,r] + Stocking.2SW.p[t+1,r], 1)
    
	} # end loop on t
      
    # ----------------------------------------------------------
    # ----------------------------------------------------------
    # End population dynamic model
    # ----------------------------------------------------------
    # ----------------------------------------------------------
      
    # Store results for mcmc draw i
    # -------------------------------
      
    logit.theta3.f[1:(n.pred+2),1:N,sFa,sWG,i] <- logit.theta3[1:(n.pred+2),1:N]
    logit.theta4.f[1:(n.pred+2),1:N,sFa,sWG,i] <- logit.theta4[1:(n.pred+2),1:N]
      
    N1.f[1:(n.pred+1),1:N,sFa,sWG,i] <- N1[1:(n.pred+1),1:N]
      
    N3.tot.f[1:(n.pred+1),1:N,sFa,sWG,i] <- N3.tot[1:(n.pred+1),1:N]
      
    N4.f[1:(n.pred+2),1:N,sFa,sWG,i] <- N4[1:(n.pred+2),1:N]
    N5.f[1:(n.pred+2),1:N,sFa,sWG,i] <- N5[1:(n.pred+2),1:N]
    N8.f[1:(n.pred+2),1:N,sFa,sWG,i] <- N8[1:(n.pred+2),1:N]
      
    N6.f[1:(n.pred+2),1:N,sFa,sWG,i] <- N6[1:(n.pred+2),1:N]
      
    N8.1.f[1:(n.pred+2),1:N,sFa,sWG,i] <- N8.1[1:(n.pred+2),1:N]
    N8.2.f[1:(n.pred+2),1:N,sFa,sWG,i] <- N8.2[1:(n.pred+2),1:N]
    N9.f[1:(n.pred+2),1:N,sFa,sWG,i] <- N9[1:(n.pred+2),1:N]
      
    N7.f[1:(n.pred+2),1:N,sFa,sWG,i] <- N7[1:(n.pred+2),1:N]
    N10.f[1:(n.pred+2),1:N,sFa,sWG,i] <- N10[1:(n.pred+2),1:N]
      
      
    # ------------------------------------------------------------------
    } # end loop i (on mcmc draws)
    # ------------------------------------------------------------------
    
    
  } # end loop scenario sFa
} # end loop scenario sWg


#############################################################################
#############################################################################
#############################################################################

# save.image("saved_forecasting_results.Rdata")
# rm(list=ls())
# load("saved_forecasting_results.Rdata")

#############################################################################
#############################################################################
#############################################################################



# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#               Calculate risk as P(returns) > CLs 
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------


# Number of eggs at the dimension of SU (x24) country (x17) or stock complexes (x3)
# ---------------------------------------------------------------------------------

dim(N1.f)


# Sum the number of eggs (N1) for all SU of the same country
# from N = 24 SU --> to N = 17 country
 
N1.f.country<- array(NA,c(n.pred+1,17,n.scenario.Fa,n.scenario.WG,n.draws))

N1.f.country[,c(1:10,12:14,16),,,] <- N1.f[,c(1:10,13:15,20),,,]
N1.f.country[,c(11),,,] <- apply(N1.f[,11:12,,,],c(1,3,4,5),sum)
N1.f.country[,c(15),,,] <- apply(N1.f[,16:19,,,],c(1,3,4,5),sum)
N1.f.country[,c(17),,,] <- apply(N1.f[,21:24,,,],c(1,3,4,5),sum)


# Sum the number of eggs for all SU of the same stock complexe

N1.f.NAC <- apply(N1.f[,1:N.NAC,,,], MARGIN=c(1,3,4,5), FUN=sum)
N1.f.SNEAC <- apply(N1.f[,(N.NAC+1):13,,,], MARGIN=c(1,3,4,5), FUN=sum)
N1.f.NNEAC <- apply(N1.f[,(13+1):N,,,], MARGIN=c(1,3,4,5), FUN=sum)



# CL at the scale of country & Complexes
# ---------------------------------------------------------

# Load CL (in eggs) for each country

load("Data/Data_CL.RData") 
CL


# Build array of CL in the same dimension than N1.f.country

CL.b <- matrix(  rep(CL, times=(n.pred+1)), ncol = 17, nrow = (n.pred+1) , byrow = T)
CL.country <- array(rep(CL.b, times=n.draws), dim = c(n.pred+1,17,n.scenario.Fa,n.scenario.WG,n.draws))
dim(CL.country)


# Conservation limit for the three stock complexes

CL.NAC <- sum(CL[1:6])
CL.SNEAC <- sum(CL[7:12])
CL.NNEAC <- sum(CL[13:17])



# Calculate risk (eggs > CL) at different spatial scales
# ------------------------------------------------------

# Country (x24)
# -------------

# Build an array of the same dimension than N1.f.country with logical values
# TRUE or FALSE depending on N1 (eggs) > or < CL

Above.CL.country <- (N1.f.country - CL.country) > 0

# Calculate risk = Prob(returns > CLs) by country

Risk.country <- apply(Above.CL.country, MARGIN=c(1,2,3,4), FUN=mean)


# Simultaneously for all country of the same complexe
# ---------------------------------------------------

# Calculate the Probability that all country of the same complex are > CL simultaneously

Above.CL.NAC.all   <- apply(Above.CL.country[,1:6,,,], MARGIN=c(1,3,4,5), FUN=prod)
Above.CL.SNEAC.all <- apply(Above.CL.country[,7:12,,,], MARGIN=c(1,3,4,5), FUN=prod)
Above.CL.NNEAC.all <- apply(Above.CL.country[,13:17,,,], MARGIN=c(1,3,4,5), FUN=prod)

Risk.NAC.all <- apply(Above.CL.NAC.all, MARGIN=c(1,2,3), FUN=mean)
Risk.SNEAC.all <- apply(Above.CL.SNEAC.all, MARGIN=c(1,2,3), FUN=mean)
Risk.NNEAC.all <- apply(Above.CL.NNEAC.all, MARGIN=c(1,2,3), FUN=mean)


# At the stock complex level (sum)
# --------------------------------

Risk.NAC <- apply((N1.f.NAC - CL.NAC)>0, MARGIN=c(1,2,3), FUN=mean)
Risk.SNEAC <- apply((N1.f.SNEAC - CL.SNEAC)>0, MARGIN=c(1,2,3), FUN=mean)
Risk.NNEAC <- apply((N1.f.NNEAC - CL.NNEAC)>0, MARGIN=c(1,2,3), FUN=mean)



#############################################################################
#############################################################################
#############################################################################


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#                                   PLOT
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Plot time series of returns, PFA ... for one scenario
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

# Scenario
# -----------

s.Fa <- 1
s.WG <- 1

# Boxplot PFA
# ------------

windows()
par(mfrow = c(4,6))
for (r in 1:N)
{
  boxplot(t(N4.f[1:(n.pred+2),r,s.Fa,s.WG,]), outline = F, ylab = "PFA (NA)", main = paste(regions24[r],sep=""))
}


# Boxplot logit.theta3
# --------------------

windows()
par(mfrow = c(4,6))
for (r in 1:N)
{
  boxplot(t(logit.theta3.f[1:(n.pred+2),r,s.Fa,s.WG,]), outline = F, ylab = "logit.theta3", main = paste(regions24[r],sep=""))
}


# Boxplot Returns 1SW (N6)
# --------------------

windows()
par(mfrow = c(4,6))
for (r in 1:N)
{
  boxplot(t(N6.f[1:(n.pred+2),r,s.Fa,s.WG,]), outline = F, ylab = "N6", main = paste(regions24[r],sep=""))
}


# Boxplot Returns 2SW (N9)
# --------------------

windows()
par(mfrow = c(4,6))
for (r in 1:N)
{
  boxplot(t(N9.f[1:(n.pred+2),r,s.Fa,s.WG,]), outline = F, ylab = "N9", main = paste(regions24[r],sep=""))
}



# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Plot Risk = Proba(Eggs > CL)
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------


lwd = 3
Year <- n.pred

windows()
par(mfrow = c(3,2))


# Risk NAC - PER COUNTRY - as a function of Greenland scenarios
# Plotted for scenarion Faroe = 1 --> 0 catches
# -------------------------------------------------

scenarios <- Scenarios.TAC.WG
s.Fa <- 1
x.label <- "Scenario WG"
y.label <- "Prob. returns > CLs"
title <- paste("NAC / Scenarios WG / Year ",start.year+1971-2+Year,sep="")

plot(scenarios,Risk.country[Year,1,s.Fa,], type = "l", col = colors17[1], lty=1,
     ylim = c(0,1), lwd = lwd,
     xlab = x.label, ylab=y.label, main = title)
for (r in 2:N.NAC)
{
  points(scenarios,Risk.country[Year,r,s.Fa,], type = "l", col = colors17[r], lty=2, lwd = lwd)
}

# add risk sum NAC
points(scenarios,Risk.NAC[Year,s.Fa,], type = "l", col = "blue", lty=2, lwd = 3*lwd)



# Risk NAC PER COUNTRY as a function of Faroes scenario
# Plotted for scenarion Greenland = 1 --> 0 catches
# --------------------------------------------------------

scenarios <- Scenarios.TAC.Fa
s.WG <- 1
x.label <- "Scenario Faroes"
y.label <- "Prob. returns > CLs"
title <- paste("NAC / Scenarios Faroes / Year ",start.year+1971-2+Year,sep="")

plot(scenarios,Risk.country[Year,1,,s.WG], type = "l", col = colors17[7], lty=1,
     ylim = c(0,1), lwd = lwd,
     xlab = x.label, ylab=y.label, main = title)
for (r in 2:6)
{
  points(scenarios,Risk.country[Year,r,,s.WG], type = "l", col = colors17[r], lty=1, lwd = lwd)
}
# add risk sum NAC
points(scenarios,Risk.NAC[Year,,s.WG], type = "l", col = "red", lty=1, lwd = lwd*3)



# Risk S.NEAC - COMPLEX LEVEL - as a function of Greenland scenario
# Plotted for scenario Faroes = 1 --> 0 catches
# ----------------------------------------------------------

scenarios <- Scenarios.TAC.WG
s.Fa <- 1
x.label <- "Scenario WG"
y.label <- "Prob. returns > CLs"
title <- paste("S.NEAC / Scenarios WG / Year ",start.year+1971-2+Year,sep="")

plot(scenarios,Risk.country[Year,7,s.Fa,], type = "l", col = colors17[7], lty=1,
     ylim = c(0,1), lwd = lwd,
     xlab = x.label, ylab=y.label, main = title)
for (r in 7:12)
{
  points(scenarios,Risk.country[Year,r,s.Fa,], type = "l", col = colors17[r], lty=1, lwd = lwd)
}

# add risk sum S.NEAC
points(scenarios,Risk.SNEAC[Year,s.Fa,], type = "l", col = "red", lty=1, lwd = lwd*3)



# Risk S.NEAC PER COUNTRY as a function of Faroes scenario
# Plotted for scenarion Greenland = 1 --> 0 catches
# --------------------------------------------------------

scenarios <- Scenarios.TAC.Fa
s.WG <- 1
x.label <- "Scenario Faroes"
y.label <- "Prob. returns > CLs"
title <- paste("S.NEAC / Scenarios Faroes / Year ",start.year+1971-2+Year,sep="")

plot(scenarios,Risk.country[Year,7,,s.WG], type = "l", col = colors17[7], lty=1,
     ylim = c(0,1), lwd = lwd,
     xlab = x.label, ylab=y.label, main = title)
for (r in 7:12)
{
  points(scenarios,Risk.country[Year,r,,s.WG], type = "l", col = colors17[r], lty=1, lwd = lwd)
}
# add risk sum S.NEAC
points(scenarios,Risk.SNEAC[Year,,s.WG], type = "l", col = "red", lty=1, lwd = lwd*3)



# Risk N.NEAC - COMPLEX LEVEL - as a function of Greenland scenario
# Plotted for scenario Faroes = 1 --> 0 catches
# ----------------------------------------------------------

scenarios <- Scenarios.TAC.WG
s.Fa <- 1
x.label <- "Scenario WG"
y.label <- "Prob. returns > CLs"
title <- paste("N.NEAC / Scenarios WG / Year ",start.year+1971-2+Year,sep="")

plot(scenarios,Risk.country[Year,13,s.Fa,], type = "l", col = colors17[7], lty=1,
     ylim = c(0,1), lwd = lwd,
     xlab = x.label, ylab=y.label, main = title)
for (r in 14:17)
{
  points(scenarios,Risk.country[Year,r,s.Fa,], type = "l", col = colors17[r], lty=1, lwd = lwd)
}

# add risk sum N.NEAC
points(scenarios,Risk.NNEAC[Year,s.Fa,], type = "l", col = "red", lty=1, lwd = lwd*3)



# Risk S.NEAC PER COUNTRY as a function of Faroes scenario
# Plotted for scenarion Greenland = 1 --> 0 catches
# --------------------------------------------------------

scenarios <- Scenarios.TAC.Fa
s.WG <- 1
x.label <- "Scenario Faroes"
y.label <- "Prob. returns > CLs"
title <- paste("S.NEAC / Scenarios Faroes / Year ",start.year+1971-2+Year,sep="")

plot(scenarios,Risk.country[Year,13,,s.WG], type = "l", col = colors17[7], lty=1,
     ylim = c(0,1), lwd = lwd,
     xlab = x.label, ylab=y.label, main = title)
for (r in 14:17)
{
  points(scenarios,Risk.country[Year,r,,s.WG], type = "l", col = colors17[r], lty=1, lwd = lwd)
}
# add risk sum N.NEAC
points(scenarios,Risk.NNEAC[Year,,s.WG], type = "l", col = "red", lty=1, lwd = lwd*3)




# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Time series of egg deposition - Fit + forecasts
# For one given scenario
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

# Number of eggs
# Bind Fitted (MCMC) and Forecasted (monte carlo)
# Year of fitted t=(n-1) is the first year of Forecasting
# -----------------------------------------------------------------

# For one particular scenario

s.Fa = 1
s.WG = 1

# Bind fitted (mcmc) and forecast (monte carlo)

library(abind)
dim(N1.mcmc)
dim(N1.f[,,s.Fa,s.WG,])
N1 <- abind(N1.mcmc[1:(start.year-1),,],N1.f[,,s.Fa,s.WG,],along = 1)
dim(N1)


# Sum the number of eggs (N1) for all SU of the same country
# from N = 24 SU --> to N = 17 country
 
N1.country <- array(NA,c(dim(N1)[1],17,n.draws))

N1.country[,c(1:10,12:14,16),] <- N1[,c(1:10,13:15,20),]
N1.country[,c(11),] <- apply(N1[,11:12,],c(1,3),sum)
N1.country[,c(15),] <- apply(N1[,16:19,],c(1,3),sum)
N1.country[,c(17),] <- apply(N1[,21:24,],c(1,3),sum)


# Sum the number of eggs for all SU of the same stock complexe

N1.NAC <- apply(N1[,1:N.NAC,], MARGIN=c(1,3), FUN=sum)
N1.SNEAC <- apply(N1[,(N.NAC+1):13,], MARGIN=c(1,3), FUN=sum)
N1.NNEAC <- apply(N1[,(13+1):N,], MARGIN=c(1,3), FUN=sum)




# NAC
# -----------------

# name_figure <- "Figure_Time series Eggs NA.png"
# resol <- 6
# png(filename = name_figure, height = 750*resol, width = 700*resol, res=72*resol)

windows()
par(mfrow = c(3,2))

ylab="Eggs"

for (r in 1:6)
{
boxplot(t(N1.country[1:start.year,r,]),xlim=c(1,dim(N1.country)[1]),ylim=c(0,(4*median(N1.country[,r,]))),outline = F, axes=F, xlab="",  ylab=ylab)
boxplot(t(N1.country[(start.year+1):dim(N1.country)[1],r,]),add=T,xlim=c(1,dim(N1.country)[1]),at=c((start.year+1):dim(N1.country)[1]),outline = F, axes=F, xlab="", col="lightpink")
abline(h=CL[r],lty=2,lwd=3,col="blue")
years <- seq(1971,2017,1)
n.years <- length(years)
  axis(side =1,at=c(seq(1,(n.years),2)), labels = years[c(seq(1,(n.years),2))], las=3, cex.axis=1.5)
  axis(side =2, cex.axis=1.5)
title(country17[r])
legend("topleft",legend=a[r],cex=2,box.lty=0)
}

# dev.off()


# S.NEAC
# -----------------

# name_figure <- "Figure_Time series Eggs S.NEAC.png"
# resol <- 6
# png(filename = name_figure, height = 750*resol, width = 700*resol, res=72*resol)

windows()
par(mfrow = c(3,2))

ylab="Eggs"

for (r in 7:12)
{
boxplot(t(N1.country[1:start.year,r,]),xlim=c(1,dim(N1.country)[1]),ylim=c(0,(4*median(N1.country[,r,]))),outline = F, axes=F, xlab="",  ylab=ylab)
boxplot(t(N1.country[(start.year+1):dim(N1.country)[1],r,]),add=T,xlim=c(1,dim(N1.country)[1]),at=c((start.year+1):dim(N1.country)[1]),outline = F, axes=F, xlab="", col="lightpink")
abline(h=CL[r],lty=2,lwd=3,col="blue")
years <- seq(1971,2017,1)
n.years <- length(years)
  axis(side =1,at=c(seq(1,(n.years),2)), labels = years[c(seq(1,(n.years),2))], las=3, cex.axis=1.5)
  axis(side =2, cex.axis=1.5)
title(country17[r])
legend("topleft",legend=a[r],cex=2,box.lty=0)
}

# dev.off()



# N.NEAC
# -----------------

# name_figure <- "Figure_Time series Eggs N.NEAC.png"
# resol <- 6
# png(filename = name_figure, height = 750*resol, width = 700*resol, res=72*resol)

windows()
par(mfrow = c(3,2))

ylab="Eggs"

for (r in 13:17)
{
boxplot(t(N1.country[1:start.year,r,]),xlim=c(1,dim(N1.country)[1]),ylim=c(0,(4*median(N1.country[,r,]))),outline = F, axes=F, xlab="",  ylab=ylab)
boxplot(t(N1.country[(start.year+1):dim(N1.country)[1],r,]),add=T,xlim=c(1,dim(N1.country)[1]),at=c((start.year+1):dim(N1.country)[1]),outline = F, axes=F, xlab="", col="lightpink")
abline(h=CL[r],lty=2,lwd=3,col="blue")
years <- seq(1971,2017,1)
n.years <- length(years)
  axis(side =1,at=c(seq(1,(n.years),2)), labels = years[c(seq(1,(n.years),2))], las=3, cex.axis=1.5)
  axis(side =2, cex.axis=1.5)
title(country17[r])
legend("topleft",legend=a[r],cex=2,box.lty=0)
}

# dev.off()



# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# Risk - Probability (Eggs > CL)Scenario W. Greenland
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------

x.label <- "Years"
y.label <- "Prob(Eggs>CL)"
years.forecast <- (start.year+1971-1):(start.year+1971-1+n.pred)
colfunc <- colorRampPalette(c("royalblue","springgreen","yellow"))


# -----------------------------------------------------------------
# Scenario W. Greenland
# -----------------------------------------------------------------

scenarios <- Scenarios.TAC.WG
s.Fa <- 1

# -------------------------------------------- 
# NAC
# --------------------------------------------

# name_figure <- "Figure_WG_NAC.png"
# resol <- 6
# png(filename = name_figure, height = 850*resol, width = 800*resol, res=72*resol)

windows()
par(mfrow = c(3,3))

# Risk all countries

for (r in 1:6)
{
plot(years.forecast,Risk.country[,r,s.Fa,1], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.country[,r,s.Fa,s], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title(country17[r])
}

# Add NAC (sum)

plot(years.forecast,Risk.NAC[,s.Fa,1], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.NAC[,s.Fa,s], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title("North America (sum)")

# Add NAC (all simul)

plot(years.forecast,Risk.NAC.all[,s.Fa,1], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.NAC.all[,s.Fa,s], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title("North America (all simult)")
# mtext("a)",cex=1,side=3, adj=-0.1)

# Add legend in an empty box

plot(x=years.forecast,y=Risk.country[,1,1,1],type="l", col="white", axes=F,xlab="",ylab="")
legend("center",legend=scenarios, col = colfunc(6),ncol=2,pch=19,cex=1.3, box.lty=0, title="Catch options (WG)")

# dev.off()



# -------------------------------------------- 
# SNEAC
# --------------------------------------------

# name_figure <- "Figure_WG_SNEAC.png"
# resol <- 6
# png(filename = name_figure, height = 850*resol, width = 800*resol, res=72*resol)

windows()
par(mfrow = c(3,3))

# Risk all countries SNEAC

for (r in 7:12)
{
plot(years.forecast,Risk.country[,r,s.Fa,1], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.country[,r,s.Fa,s], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title(country17[r])
}

# Add S.NEAC (sum)

plot(years.forecast,Risk.SNEAC[,s.Fa,1], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.SNEAC[,s.Fa,s], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title("Southern NEAC (sum)")


# Add S.NEAC (all simult)

plot(years.forecast,Risk.SNEAC.all[,s.Fa,1], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.SNEAC.all[,s.Fa,s], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title("Southern NEAC (all simult)")
# mtext("a)",cex=1,side=3, adj=-0.1)


# Add legend in an empty box

plot(x=years.forecast,y=Risk.country[,1,1,1],type="l", col="white", axes=F,xlab="",ylab="")
legend("center",legend=scenarios, col = colfunc(6),ncol=2,pch=19,cex=1.3, box.lty=0, title="Catch options (WG)")

# dev.off()



# -------------------------------------------- 
# N.NEAC
# --------------------------------------------

# name_figure <- "Figure_WG_NNEAC.png"
# resol <- 6
# png(filename = name_figure, height = 850*resol, width = 800*resol, res=72*resol)

windows()
par(mfrow = c(3,3))

# Risk all countries SNEAC

for (r in 13:17)
{
plot(years.forecast,Risk.country[,r,s.Fa,1], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.country[,r,s.Fa,s], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title(country17[r])
}

# Add N.NEAC (sum)

plot(years.forecast,Risk.NNEAC[,s.Fa,1], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.NNEAC[,s.Fa,s], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title("Northern NEAC (sum)")


# Add N.NEAC (all simult)

plot(years.forecast,Risk.NNEAC.all[,s.Fa,1], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.NNEAC.all[,s.Fa,s], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title("Northern NEAC (all simult)")
# mtext("a)",cex=1,side=3, adj=-0.1)


# Add legend in an empty box

plot(x=years.forecast,y=Risk.country[,1,1,1],type="l", col="white", axes=F,xlab="",ylab="")
legend("center",legend=scenarios, col = colfunc(6),ncol=2,pch=19,cex=1.3, box.lty=0, title="Catch options (WG)")

# dev.off()




# -----------------------------------------------------------------
# Scenarios Faroes
# -----------------------------------------------------------------

scenarios <- Scenarios.TAC.Fa
s.WG <- 1

# -------------------------------------------- 
# NAC
# --------------------------------------------

# name_figure <- "Figure_Fa_NAC.png"
# resol <- 6
# png(filename = name_figure, height = 850*resol, width = 800*resol, res=72*resol)

windows()
par(mfrow = c(3,3))

# Risk all countries

for (r in 1:6)
{
plot(years.forecast,Risk.country[,r,1,s.WG], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.country[,r,s,s.WG], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title(country17[r])
}

# Add NAC (sum)

plot(years.forecast,Risk.NAC[,1,s.WG], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.NAC[,s,s.WG], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title("North America")

# Add NAC (all simul)

plot(years.forecast,Risk.NAC.all[,1,s.WG], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.NAC.all[,s,s.WG], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title("North America (all simult)")
# mtext("a)",cex=1,side=3, adj=-0.1)

# Add legend in an empty box

plot(x=years.forecast,y=Risk.country[,1,1,1],type="l", col="white", axes=F,xlab="",ylab="")
legend("center",legend=scenarios, col = colfunc(6),ncol=2,pch=19,cex=1.3, box.lty=0, title="Catch options (Fa)")

# dev.off()



# -------------------------------------------- 
# SNEAC
# --------------------------------------------

# name_figure <- "Figure_Fa_SNEAC.png"
# resol <- 6
# png(filename = name_figure, height = 850*resol, width = 800*resol, res=72*resol)

windows()
par(mfrow = c(3,3))

# Risk all countries SNEAC

for (r in 7:12)
{
plot(years.forecast,Risk.country[,r,1,s.WG], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.country[,r,s,s.WG], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title(country17[r])
}

# Add S.NEAC (sum)

plot(years.forecast,Risk.SNEAC[,1,s.WG], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.SNEAC[,s,s.WG], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title("Southern NEAC (sum)")


# Add S.NEAC (all simult)

plot(years.forecast,Risk.SNEAC.all[,1,s.WG], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.SNEAC.all[,s,s.WG], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title("Southern NEAC (all simult)")
# mtext("a)",cex=1,side=3, adj=-0.1)


# Add legend in an empty box

plot(x=years.forecast,y=Risk.country[,1,1,1],type="l", col="white", axes=F,xlab="",ylab="")
legend("center",legend=scenarios, col = colfunc(6),ncol=2,pch=19,cex=1.3, box.lty=0, title="Catch options (Fa)")

# dev.off()



# -------------------------------------------- 
# N.NEAC
# --------------------------------------------

# name_figure <- "Figure_Fa_NNEAC.png"
# resol <- 6
# png(filename = name_figure, height = 850*resol, width = 800*resol, res=72*resol)

windows()
par(mfrow = c(3,3))

# Risk all countries N.NEAC

for (r in 13:17)
{
plot(years.forecast,Risk.country[,r,1,s.WG], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.country[,r,s,s.WG], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title(country17[r])
}

# Add N.NEAC (sum)

plot(years.forecast,Risk.NNEAC[,1,s.WG], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.NNEAC[,s,s.WG], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title("Northern NEAC (sum)")


# Add N.NEAC (all simult)

plot(years.forecast,Risk.NNEAC.all[,1,s.WG], type = "l", col = colfunc(6)[1], lty=1,
	ylim = c(0,1), lwd = 3,
	xlab = x.label, ylab=y.label)

for (s in 2:length(scenarios))
{
points(years.forecast,Risk.NNEAC.all[,s,s.WG], type = "l", lty=1,col=colfunc(6)[s],lwd=1)
}
title("Northern NEAC (all simult)")
# mtext("a)",cex=1,side=3, adj=-0.1)


# Add legend in an empty box

plot(x=years.forecast,y=Risk.country[,1,1,1],type="l", col="white", axes=F,xlab="",ylab="")
legend("center",legend=scenarios, col = colfunc(6),ncol=2,pch=19,cex=1.3, box.lty=0, title="Catch options (Fa)")

# dev.off()



# -----------------------------------------------------------------
# -----------------------------------------------------------------
# Risk - Faroes & Greenland
# -----------------------------------------------------------------
# -----------------------------------------------------------------

Year = 4

source("Function/function.MyImagePlot.R")

for (r in 1:17)
{
windows()
x <- Risk.country[Year,r,,]
dim(x)
min(x)
max(x)
function.MyImagePlot(x)
title(country17[r])
}








