# Fit the life cycle with Nimble
# This program reads the model coded in Nimble language (=BUGS language)
# in "nimble_model.txt" file

# V. - E. Rivot, M. Olmos - 28 March 2019

rm(list = ls(all=TRUE))

library(coda)
library(MASS)
library(nimble)
library(parallel)



# Control MCMC configuration
# ----------------------------------------------

# n.burnin included in n.iter
# thin included in n.burnin and n.iter
# The total number of posterior samples returned is floor ((niter-nburnin)/thin)

# Conf trial compil - run
# n.thin = 1				
# n.keep = 100			
# n.burnin.beforethin = 100 	
# name_file_mcmc <- "mcmc_nimble_Conf0.RData"

# Conf recommander to store results 
n.thin = 500
n.keep = 5000
n.burnin.beforethin = 10000
name_file_mcmc <- "mcmc_nimble.RData"

n.iter = n.keep*n.thin + n.burnin.beforethin

n.chains = 2



####################################################################
# Control for parallel computation
# Parallel computation save time but does not allow to monitor
# progress bars

# para  = "FALSE"
para = "TRUE"

####################################################################


################################################
if(para == "FALSE") {
################################################

# Simple computation
# -------------------

# Load data, constants and inits for Nimble

load("Data/Data_nimble.RData")
load("Data/Const_nimble.RData")
load("Inits/inits_nimble.RData")

source("Data/Source_Index.R")

names(inits[[1]])
names(inits[[2]])

# if needed, remove variables
# names(Const_nimble)
# Const_nimble$N.Sample.sm <- 100
# Const_nimble <- Const_nimble[-which(names(Const_nimble)=="omega")]
# save(Const_nimble, file = "Const_nimble.RData")
# save(Data_nimble, file = "Data_nimble.RData")

# List variables for which MCMC samples must be stored
# Those variables below are needed to run forecasting
monitor <- c(
	# Abundance
		"N1","N2","N3","N3.tot","N4","N5","N8","N6","N9","N8.1","N8.2","N7","N10",
	# Harvest rates
		"h5.NAC.1", "h5.NAC.2", "h5.NAC.3", 
		"h8.NEAC.1","h8.NAC.1",
		"h8.2",
		"h8.NEAC.3","h8.NAC.3","h8.NAC.4",
	# Survival and prop maturing
		"Surv.eggs","logit.theta3","logit.theta4",
		# "Surv.eggs","theta3","theta4",
		"tau.theta3","tau.theta4",
	# Proportion smolt-ages
		"prop_gamma"
		# ,"M"
		# "theta1.ddp"
)

# Load model code 
source("Model/model_nimble.r")               

# Create Nimble model 
# set.seed(1)
               
my.nimbleModel <- nimbleModel(code = model.nimble, name = 'model',
							constants = Const_nimble, data = Data_nimble, 
							inits = inits[[1]])

# Get info on initialization							

my.nimbleModel$initializeInfo()

# Compile Nimble Model 

my.compileNimble <- compileNimble(my.nimbleModel)

# Generate an MCMC configuration	
               
my.configureMCMC <- configureMCMC(my.nimbleModel, monitors = monitor, autoBlock = FALSE)
               
# Build the R executable MCMC sampler
               
my.buildMCMC <- buildMCMC(my.configureMCMC)
               
# Compile the MCMC sampler in the same project than the model
               
my.compileNimbleMCMC <- compileNimble(my.buildMCMC, project = my.nimbleModel, showCompilerOutput = FALSE)	

# Run MCMC
               
mcmc_nimble <- runMCMC(my.compileNimbleMCMC,
			niter = n.iter, 
			nburnin = n.burnin.beforethin,
			nchains = n.chains, 
			thin = n.thin, 
			inits = inits,
			progressBar = TRUE, 
			samples = TRUE, 
			samplesAsCodaMCMC = TRUE, 
			summary = FALSE, 
			WAIC = FALSE)



} # end para = FALSE 
####################################################################


####################################################################
if(para == "TRUE") {
####################################################################

# 1 - Create a cluster with n nodes (here n = n.chains)

cl <- makeCluster(n.chains, outfile = "")

# 2 - Clone everything that is needed in each node
# including the libraries needed to run the model

clusterEvalQ(cl, {
       
library(nimble)
library(coda)

# Load data, constans and inits for Nimble

load("Data/Data_nimble.RData")
load("Data/Const_nimble.RData")
load("Inits/inits_nimble.RData")

# Load model code 
source("Model/model_nimble.r")               

# List all the variables for which MCMC samples must be stored
monitor <- c(
	# Abundance
		"N1","N2","N3","N3.tot","N4","N5","N8","N6","N9","N8.1","N8.2","N7","N10",
	# Harvest rates
		"h5.NAC.1", "h5.NAC.2", "h5.NAC.3", 
		"h8.NEAC.1","h8.NAC.1",
		"h8.2",
		"h8.NEAC.3","h8.NAC.3","h8.NAC.4",
	# Survival and propr maturing
		"Surv.eggs","logit.theta3","logit.theta4",
		# "Surv.eggs","theta3","theta4",
		"tau.theta3","tau.theta4",
	# Proportion smolt-ages
		"prop_gamma"
		# ,"M"
		# "theta1.ddp"
)

# Create Nimble model 
# set.seed(1)
               
my.nimbleModel <- nimbleModel(code = model.nimble, name = 'model', 
							constants = Const_nimble, data = Data_nimble,
							inits = inits[[1]]	)

# Compile Nimble Model 

my.compileNimble <- compileNimble(my.nimbleModel)
               
# Configure MCMC sampler    
            
my.configureMCMC <- configureMCMC(my.nimbleModel, monitors = monitor, autoBlock = FALSE)
               
# Build the R executable MCMC sampler
               
my.buildMCMC <- buildMCMC(my.configureMCMC)
               
# Compile the MCMC sampler in the same Project than the model
               
my.compileNimbleMCMC <- compileNimble(my.buildMCMC, project = my.nimbleModel, showCompilerOutput = FALSE)	
               
})

# A function to run the compiled nimble model
# Will be run with 1 chain in each cluster, starting from different inits

mcmc_nimble_1chain <- function(inits.1chain)
{
runMCMC(my.compileNimbleMCMC,
          niter = n.iter, 
          nburnin = n.burnin.beforethin,
          nchains = 1, 
	    thin = n.thin, 
          inits = inits.1chain,
          progressBar = TRUE, 
          samples = TRUE, 
          samplesAsCodaMCMC = TRUE, 
          summary = FALSE, 
          WAIC = FALSE)
}

# Clone all other arguments needed to run the function

clusterExport(cl, c('n.iter','n.burnin.beforethin','n.thin')) 

# A list of values that will be used to run the function in each node of the cluster

load("Inits/inits_nimble.RData")
values <- inits

# Run the function in each cluster, starting from inits stored in "values"
# Outputs will be aggregated as a list

mcmc_parallel <- parLapply(cl, values, fun = mcmc_nimble_1chain)  

# Close the clusters

stopCluster(cl) 

# Compile MCMC samples of different chains in a single mcmc.list object

mcmc_nimble <- mcmc.list(mcmc_parallel)


} # end para = TRUE 
####################################################################


# Save MCMC outputs in the desire file# Saving format is mcmc.list

setwd("./Results")
save(mcmc_nimble, file = name_file_mcmc)
setwd("../")

