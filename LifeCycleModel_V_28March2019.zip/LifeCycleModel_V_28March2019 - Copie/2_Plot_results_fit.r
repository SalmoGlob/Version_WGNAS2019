# Plot results
# The program needs the mcmc outputs, the data and the constants
# Those are read before running script plot
 
# V. - E. Rivot, M. Olmos - 28 March 2019



rm(list=ls())

library(coda)
library(rjags)
library("bayesplot")
library("ggplot2")
library(boot)


# Load MCMC samples
# ------------------------------

# load("Results/mcmc_nimble_Conf0.Rdata")
load("Results/mcmc_nimble.Rdata")

# "N1","N2","N4","N5","N3","N6","N9","logit.theta3","logit.theta4", "h8.2", "h5.NEAC.1"

# Names of the variables stored in the mcmc list

# varnames(mcmc_nimble)
niter(mcmc_nimble)
nchain(mcmc_nimble)
nvar(mcmc_nimble)



# Data
# ------------------------

load("Data/Const_nimble.RData")
load("Data/Data_nimble.RData")

source("Data/Source_Index.R")
regions24
country17

data <- c(Data_nimble,Const_nimble)
names(data)

n <- data$n
year1 <- 1975
years <- year1:(year1 + n -4)
N <- data$N 


###########################################################################
#  Function to extract variables from MCMC list objects
###########################################################################

# Extract the variable of interest from the mcmc list
# mcmc.var is still an mcmc list but contains only the variable of interest
# --------------------------------------------

var = "logit.theta3"
# mcmc.var = mcmc_nimble[,which(substr(varnames(mcmc_nimble),1,nchar(var)+1)==paste(var,"[",sep=""))]
mcmc.var = mcmc_nimble[,which(substr(varnames(mcmc_nimble),1,nchar(var))==var)]
varnames(mcmc.var)


# For variables as 2D arrays [y,r]
# Extract a time series for one particular SU
# function "extract.var.r <- function(var,r)"
# ---------------------------------------------

extract.var.r <- function(var,r)
{
# Create the list of names corresponding to the series for one area
liste.name <- NULL
for(y in 1:n)
{
x <- paste(var,"[",y,", ",r,"]", sep = "")
liste.name <- c(liste.name,x)
}

# Find corresponding Index in the mcmc list
index.name <- NULL
for (i in 1:length(liste.name))
{
  I <- which(varnames(mcmc_nimble) == liste.name[i])
  index.name <- c(index.name,I)
}

# Extract 
mcmc.var.r <- mcmc_nimble[,index.name]

res <- list(mcmc.var.r = mcmc.var.r)
}


# Example

var = "logit.theta3"
r = 10  # Eastern Scotland
res <- extract.var.r(var=var, r=r)$mcmc.var.r
varnames(res)
if (is.null(varnames(res))==TRUE) {print("no variable with such name")}


# Extract one single element
# ---------------------------------------------

var = "logit.theta3[25, 7]"
mcmc_nimble[,var]

###########################################################################



# Plot MCMC chains
# --------------------------------

# var="logit.theta3"
#var="logit.theta4"

var="theta3"
#var="theta4"

#var="N4"
#var="N5"
#var="N8"
#var = "N2"

for (r in 1:N)
{
windows() ; par(mfrow=c(4,1))

for (t in seq(10,40,10))
{

## acfplot bugs because of layout issue (works when a variable of dim 1 is selected)
## acfplot(mcmc_nimble[,paste(var,"[",t,", ",r,"]",sep="")]) # ,main=paste(var,"[",t,",",r,"]",sep=""))

traceplot(mcmc_nimble[,paste(var,"[",t,", ",r,"]",sep="")],main=paste(var,"[",t,",",r,"]",sep=""))
# densplot(mcmc_nimble[,paste(var,"[",t,", ",r,"]",sep="")],main=paste(var,"[",t,",",r,"]",sep=""))
# autocorr.plot(mcmc_nimble[,paste(var,"[",t,", ",r,"]",sep="")], main=paste(var,"[",t,",",r,"]",sep=""), lag.max = 100, auto.layout=FALSE)

}}



# Traceplot of variance-covariance matrix
# -----------------------------------------

var = "tau.theta3"
# var = "tau.theta4"

for (i in 1:N)
{
windows() ; par(mfrow=c(4,6))
for (j in 1:N)
{

## acfplot bugs because of layout issue (works when a variable of dim 1 is selected)
## acfplot(mcmc_nimble[,paste(var,"[",i,", ",j,"]",sep="")]) # ,main=paste(var,"[",i,",",j,"]",sep=""))

# traceplot(mcmc_nimble[,paste(var,"[",i,", ",j,"]",sep="")],main=paste(var,"[",i,",",j,"]",sep=""))

## densplot(mcmc_nimble[,paste(var,"[",i,", ",j,"]",sep="")],main=paste(var,"[",i,",",j,"]",sep=""))
## autocorr.plot(mcmc_nimble[,paste(var,"[",i,", ",j,"]",sep="")], main=paste(var,"[",i,",",j,"]",sep=""), lag.max = 100, auto.layout=FALSE)

}}




# Exttact median to plot time series
# -----------------------------------

# Transform mcmc.list into matrix

Mat <- as.matrix(mcmc_nimble)
colnames(Mat)

x = "h8.2"
h8.2.mcmc = Mat[,which(substr(colnames(Mat),1,nchar(x)+1)==paste(x,"[",sep=""))]
h8.2.c = apply(h8.2.mcmc,2,median)
h8.2.c <- matrix(h8.2.c, dim(h8.2.mcmc)[2]/N, N)

x = "N1"
N1.mcmc = Mat[,which(substr(colnames(Mat),1,nchar(x)+1)==paste(x,"[",sep=""))]
N1.c = apply(N1.mcmc,2,median)
N1.c <- matrix(N1.c, (n-1), N)

x = "N2"
N2.mcmc = Mat[,which(substr(colnames(Mat),1,nchar(x)+1)==paste(x,"[",sep=""))]
N2.c = apply(N2.mcmc,2,median)
N2.c <- matrix(N2.c, (n-1), N)

theta1.mcmc.ddp.0.4 <- N2.mcmc/N1.mcmc
theta1.mcmc = apply(theta1.mcmc.ddp.0.4 ,2,median)
theta1.c <- matrix(theta1.mcmc,dim(theta1.mcmc.ddp.0.4)[2]/N, N)

x = "logit.theta3"
theta3.mcmc = Mat[,which(substr(colnames(Mat),1,nchar(x)+1)==paste(x,"[",sep=""))]
theta3.c = apply(theta3.mcmc,2,median)
dim(theta3.mcmc)
theta3.c <- matrix(theta3.c, dim(theta3.mcmc)[2]/N, N)

x = "logit.theta4"
theta4.mcmc = Mat[,which(substr(colnames(Mat),1,nchar(x)+1)==paste(x,"[",sep=""))]
theta4.c = apply(theta4.mcmc,2,median)
theta4.c <- matrix(theta4.c,dim(theta4.mcmc)[2]/N, N)

x = "tau.theta3"
tau.theta3.mcmc = Mat[,which(substr(colnames(Mat),1,nchar(x)+1)==paste(x,"[",sep=""))]
tau.theta3.c = apply(tau.theta3.mcmc,2,median)

x = "tau.theta4"
tau.theta4.mcmc = Mat[,which(substr(colnames(Mat),1,nchar(x)+1)==paste(x,"[",sep=""))]
tau.theta4.c = apply(tau.theta4.mcmc,2,median)

tau.theta3.m<-matrix(tau.theta3.c,N,N)
tau.theta4.m<-matrix(tau.theta4.c,N,N)

var.theta3.m <- solve(tau.theta3.m)
var.theta4.m <- solve(tau.theta4.m)



############################################################################################
#                                              PLOT
############################################################################################



size.text <- 1
size.labels <- 0.8
cex.abc <- 1
box.size <- 0.5
col1 <- rep("white",50)
y.label = ""
x.label = " "
c.max <- -15
c.min <- 1


# Egg-smolt survival
# ----------------------------

X <- theta1.c

windows()
# name_figure <- "Figure_0.png"
# resol <- 6
# png(filename = name_figure, height = 750*resol, width = 600*resol, res=72*resol)

plot(X[5:42,1],pch=20,ylim=c(min(X),max(X)),cex.main=1.2,
     ylab=x.label, xlab="", cex.lab=1, cex.axis=1, type="l", lwd=2,
     xaxt="n", yaxt="n", lty=1, col=colors24[1], main="eggs-smolts survival",axes=F)
for (r in 2:N) 
{
  lines(X[5:42,r],lwd=2,lty=typepoint24[r],col=colors24[r])
}

lines(apply(X[5:42,1:6],1,mean),lwd=10,lty=1,col="green")
lines(apply(X[5:42,7:13],1,mean),lwd=10,lty=1,col="red")
lines(apply(X[5:42,14:24],1,mean),lwd=10,lty=1,col="blue")
# lines(apply(X,1,mean),lwd=7,col="ivory4")

axis(side =1,at=c(seq(1,length(years),4)), labels = years[c(seq(1,length(years),4))], cex.axis=size.labels,las=1)
axis(side =2, cex.axis=size.labels,las=2)

# dev.off()




# Post-Smolt survival
# ----------------------------

X <- theta3.c

windows()
# name_figure <- "Figure_1.png"
# resol <- 6
# png(filename = name_figure, height = 750*resol, width = 600*resol, res=72*resol)

plot(X[5:42,1],pch=20,ylim=c(-6.2,max(X)),cex.main=1.2,
     ylab=x.label, xlab="", cex.lab=1, cex.axis=1, type="l", lwd=2,
     xaxt="n", yaxt="n", lty=1, col=colors24[1], main="smolt-PFA survival",axes=F)
for (r in 2:N) 
{
  lines(X[5:42,r],lwd=2,lty=typepoint24[r],col=colors24[r])
}

lines(apply(X[5:42,1:6],1,mean),lwd=10,lty=1,col="green")
lines(apply(X[5:42,7:13],1,mean),lwd=10,lty=1,col="red")
lines(apply(X[5:42,14:24],1,mean),lwd=10,lty=1,col="blue")


#lines(apply(X,1,mean),lwd=7,col="ivory4")
axis(side =1,at=c(seq(1,length(years),4)), labels = years[c(seq(1,length(years),4))], cex.axis=size.labels,las=1)
axis(side =2, cex.axis=size.labels,las=2)

# dev.off()




# Proportion of 1SW maturing
# ----------------------------

X <- theta4.c

windows()
# name_figure <- "Figure_3.png"
# resol <- 6
# png(filename = name_figure, height = 750*resol, width = 600*resol, res=72*resol)

plot(X[5:42,1],pch=20,ylim=c(min(X),max(X)),cex.main=1.2,
     ylab=x.label, xlab="", cex.lab=1, cex.axis=1, type="l", lwd=2,
     xaxt="n", yaxt="n", lty=1, col=colors24[1], main="Proportion PFA maturing",axes=F)
for (r in 2:N) 
{
  lines(X[5:42,r],lwd=2,lty=typepoint24[r],col=colors24[r])
}

lines(apply(X[5:42,1:6],1,mean),lwd=10,lty=1,col="green")
lines(apply(X[5:42,7:13],1,mean),lwd=10,lty=1,col="red")
lines(apply(X[5:42,14:24],1,mean),lwd=10,lty=1,col="blue")


#lines(apply(X,1,mean),lwd=7,col="ivory4")
axis(side =1,at=c(seq(1,length(years),4)), labels = years[c(seq(1,length(years),4))], cex.axis=size.labels,las=1)
axis(side =2, cex.axis=size.labels,las=2)

# dev.off() #




# WG exploitation rate
# ----------------------------

X <- h8.2.c

n.years.plot <- n-5

windows()
# name_figure <- "Figure_5.png"
# resol <- 6
# png(filename = name_figure, height = 750*resol, width = 600*resol, res=72*resol)

plot(X[5:42,1],pch=20,ylim=c(min(X),max(X)),cex.main=1.2,
     ylab=x.label, xlab="", cex.lab=1, cex.axis=1, type="l", lwd=2,
     xaxt="n", yaxt="n", lty=1, col=colors24[1], main="Harvest rate - Greenland fishery",axes=F)
for (r in 2:N) 
{
  lines(X[5:42,r],lwd=2,lty=typepoint24[r],col=colors24[r])
}

lines(apply(X[5:42,1:6],1,mean),lwd=10,lty=1,col="green")
lines(apply(X[5:42,7:13],1,mean),lwd=10,lty=1,col="red")
lines(apply(X[5:42,14:24],1,mean),lwd=10,lty=1,col="blue")


#lines(apply(X,1,mean),lwd=7,col="ivory4")
axis(side =1,at=c(seq(1,length(years),4)), labels = years[c(seq(1,length(years),4))], cex.axis=size.labels,las=1)
axis(side =2, cex.axis=size.labels,las=2)

# dev.off()




# Plot  variance-covariance matrix theta 3 and theta4
# ---------------------------------------------------

# prepare cov/cor matrix
library(corrplot)

var.theta3 <- cov2cor(var.theta3.m)
var.theta4 <- cov2cor(var.theta4.m)

colnames(var.theta3) <- regions24
rownames(var.theta3) <- regions24
colnames(var.theta4) <- regions24
rownames(var.theta4) <- regions24

windows()

# name_figure <- "Figure_2.png"
# resol <- 6
# png(filename = name_figure, height = 750*resol, width = 600*resol, res=72*resol)

col <- colorRampPalette(c("#BB4444", "#EE9988", "#FFFFFF", "#77AADD", "#4477AA"))


corrplot((var.theta3)
, method="color"
, col=col(100)
,  type="upper"
,  addCoef.col = "black", 
# Ajout du coefficient de corr�lation
,tl.col="black"
, tl.srt=45, diag=F,number.cex = .7, main = "Correlation matrix - marine survival")
#mtext("(b)" ,side = 3, adj = 0, cex=1.5,3.3)
#box("figure", col="red")  

# dev.off()


## Correlation matrix prop. maturing 1SW
#--------------------------------------------

windows()

corrplot((var.theta4)
, method="color"
, col=col(100)
,  type="upper"
,  addCoef.col = "black", 
# Ajout du coefficient de corr�lation
,tl.col="black"
, tl.srt=45, diag=F,number.cex = .7, main = "Correlation matrix - prop. maturing PFA")
#mtext("(b)" ,side = 3, adj = 0, cex=1.5,3.3)
#box("figure", col="red")  

# dev.off() #







