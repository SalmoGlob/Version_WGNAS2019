# Transform catch scenarios in Faroes in tons into catches in number
# Adapted from NEAC Forecasting model - Ted Potter - WGNAS 2015 Stock Annex

# Function to convert TAC options in Faroes in Kg

# --> into a number of fish that really die in Faroe Fishery
# Accounts for several things:
# - transform weight in number using mean weight of fish
# - accounts for discards and mortality rate of discard
# - account for the "sharing" agreement in Faroes
# - accounts for the proportion if farmed fish in the catches
# - automatically calculate the proportion of 1SWm, 1SWnm and 2SW in the catches


function.convert.scenario.Faroes <- function(TAC.in.kg)
{

# Source Faroes data file
# Mean weight, Proportion 1SW in catches, Discard rate
Data_FA_fishery <- read.table("Data/Data_FA_Fishery_TedPotterWGNAS2015.txt", header = TRUE)

# Discard rate = mean of different sample
DiscRate <- mean(Data_FA_fishery$DiscRate)

# Mean Weight of fish in Faroe fishery
Mean.Weight <- mean(Data_FA_fishery$MeanWt)

# Mean proportion of 1SW in Faroes catches
Mean.Prop1SW <- mean(Data_FA_fishery$Prop1SW)

# "share allocation" for Faroes from NEAC harvestable surplus
FaroeShare  <- 0.084

# Proportion of 1SW catch that would have matured as MSW
Delayed1SW	<- 0.22

# proportion of discards that die
DiscMort	<- 0.8		

# Faroes catch proportion from NEAC stocks			
FA.prop1SWmat_NEAC 	<- 0.943
FA.prop1SWnmat_NEAC <- 0.795
FA.prop2SW 			<- 0.795

# Correction to reduce prop farmed fish at faroes based on more recent info 
# Following ICES WGNAS 2015 Stock Annex pp. 58, the proportion of farmed fish in captures is  mean(Farm)*FarmCorr
Farm     <- c(0.17, 0.43, 0.42, 0.37, 0.27, 0.17, 0.19) 	# Historic estimates of farmed prop'n
mean.Farm.Prop <- mean(Farm)
FarmCorr <- 0.63											# Correction factor from Norwegian data (Hansen pers comm)

# Calculate the total number of wild fish that will really be caught given one scenario
# 1. Calculate mean number by dividing by the mean weight
# 2. Accounting for the Faroe Share allocation
# 3. Accounting for discard rate and a non 100% mortality rate for discard
# 4. Finally accounting for the proportion of farmed fish --> fish that really die
TAC.in.number <- (TAC.in.kg/FaroeShare)/Mean.Weight
nb.that.really.die <- (TAC.in.number + TAC.in.number*(DiscRate/(1-DiscRate))*DiscMort) * (1- mean.Farm.Prop*FarmCorr)

nb.that.really.die.1SWm <- Mean.Prop1SW * (1-Delayed1SW) * FA.prop1SWmat_NEAC* nb.that.really.die
nb.that.really.die.1SWnm <- Mean.Prop1SW * Delayed1SW * FA.prop1SWnmat_NEAC* nb.that.really.die
nb.that.really.die.2SW <- (1-Mean.Prop1SW) * FA.prop2SW * nb.that.really.die

CF1.m.p <- nb.that.really.die.1SWm
CF1.nm.p <- nb.that.really.die.1SWnm
CF2.p <- nb.that.really.die.2SW

list("CF1.m.p" = CF1.m.p, "CF1.nm.p" = CF1.nm.p, "CF2.p" = CF2.p)

}





