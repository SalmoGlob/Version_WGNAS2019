# Transform catch scenarios in tons in WG into catches in number
# Adapted from NAC Forecasting model - Gerald Chaput - WGNAS 2018

# Function to convert TAC in WG in Kg
# into a number of fish that really die in WG fishery
# Accounts for several things:
# - transfom weight in number using mean weight of fish
# - accounts for unreported catches
# - account for the "sharing" agreement in WG

function.convert.scenario.WG <- function(TAC.in.kg)
{

# Source WG data file
# Mean weigth, unreported rate ...

Data_WG_fishery <- read.table("Data/Data_WG_fishery_GeraldChaputWGNAS2018.csv", header = TRUE, sep = ";")
n.years <- dim(Data_WG_fishery)[1]


# Mean Weigth of fish in Faroe fishery

Mean.Weigth <- mean(Data_WG_fishery$WGMeanWt[(n.years-4):n.years])


# Mean unreported catch rate

Mean.Unr <- mean(Data_WG_fishery$WGUnHarv[(n.years-4):n.years])/100


# Mean proportion of 1SW non maturing in catches

Mean.Prop.1SWnm <- mean((Data_WG_fishery$WGProp1SWNAC[(n.years-4):n.years] + Data_WG_fishery$WGProp1SWNEAC[(n.years-4):n.years])/2)


# "share allocation" for Greenland catches
# Mean that a quotas of 40t will lead to a total catch of 100t

WGShare    <- 0.40


# Calculate the total number of fish that will really be caught
# 1. Calculate mean number by dividing by the mean weight
# 2. Accounting for the Faroe Share allocation
# 3. Accounting for discard rate and a non 100% mortality rate for discard --> fish that really die

TAC.in.number <- (TAC.in.kg/WGShare)/Mean.Weigth
nb.that.really.die <- TAC.in.number*(1+Mean.Unr)*Mean.Prop.1SWnm

list("CG2.p" = nb.that.really.die)

}





